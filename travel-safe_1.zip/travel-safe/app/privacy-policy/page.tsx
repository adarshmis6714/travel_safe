import { LegalPage } from "@/components/ui/LegalPage";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy",
  alternates: { canonical: "/privacy-policy" },
};

export default function PrivacyPolicyPage() {
  return (
    <LegalPage title="Privacy Policy" updated="July 1, 2026">
      <p>
        Travel Safe Holidays Pvt. Ltd. (&ldquo;Travel Safe&rdquo;,
        &ldquo;we&rdquo;, &ldquo;us&rdquo;) respects your privacy. This
        policy explains what information we collect when you use our website
        or book a trip with us, how we use it, and the choices you have.
      </p>

      <h2>Information We Collect</h2>
      <ul>
        <li>Contact details you submit through enquiry, booking, or newsletter forms — name, phone, email.</li>
        <li>Trip preferences — destination, travel dates, budget, and number of travellers.</li>
        <li>Technical data — device type, browser, and pages visited, collected via analytics tools.</li>
      </ul>

      <h2>How We Use Your Information</h2>
      <p>
        We use the information you provide to respond to enquiries, prepare
        itineraries and quotes, process bookings, and send updates related to
        your trip. With your consent, we may also send occasional newsletters
        with offers and travel guides.
      </p>

      <h2>Sharing of Information</h2>
      <p>
        We share booking details with hotels, airlines, and local operators
        strictly as needed to fulfil your trip. We do not sell your personal
        information to third parties.
      </p>

      <h2>Data Security</h2>
      <p>
        Payment information is processed through encrypted, PCI-compliant
        payment gateways. We retain personal data only as long as necessary
        to provide our services and meet legal obligations.
      </p>

      <h2>Your Choices</h2>
      <p>
        You can request access to, correction of, or deletion of your
        personal data, and unsubscribe from marketing emails at any time, by
        writing to{" "}
        <a href="mailto:privacy@travelsafe.com">privacy@travelsafe.com</a>.
      </p>

      <h2>Contact</h2>
      <p>
        Questions about this policy can be directed to our privacy team at{" "}
        <a href="mailto:privacy@travelsafe.com">privacy@travelsafe.com</a>.
      </p>
    </LegalPage>
  );
}
