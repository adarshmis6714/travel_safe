import { CallButton } from "@/components/layout/CallButton";
import { Footer } from "@/components/layout/Footer";
import { Navbar } from "@/components/layout/Navbar";
import { ThemeProvider } from "@/components/layout/ThemeProvider";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import type { Metadata } from "next";
import { Poppins, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  variable: "--font-poppins",
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["500", "700"],
  variable: "--font-mono",
  display: "swap",
});

const siteUrl = "https://www.travelsafe.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Travel Safe | Explore the World with Confidence",
    template: "%s | Travel Safe",
  },
  description:
    "Travel Safe designs handpicked international, domestic, honeymoon, group and corporate tour packages backed by verified stays, transparent pricing, and 24x7 support.",
  keywords: [
    "travel agency",
    "tour packages",
    "international tours",
    "domestic tours",
    "honeymoon packages",
    "visa services",
    "Travel Safe",
  ],
  authors: [{ name: "Travel Safe" }],
  openGraph: {
    type: "website",
    url: siteUrl,
    siteName: "Travel Safe",
    title: "Travel Safe | Explore the World with Confidence",
    description:
      "Handpicked tour packages, verified stays, and 24x7 support for confident travel — worldwide.",
    images: [
      {
        url: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=1200&auto=format&fit=crop",
        width: 1200,
        height: 630,
        alt: "Travel Safe — Explore the World with Confidence",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Travel Safe | Explore the World with Confidence",
    description:
      "Handpicked tour packages, verified stays, and 24x7 support for confident travel — worldwide.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${poppins.variable} ${mono.variable} font-sans`}>
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "TravelAgency",
              name: "Travel Safe",
              url: siteUrl,
              logo: `${siteUrl}/logo.png`,
              description:
                "Travel Safe designs handpicked tour packages backed by verified stays, transparent pricing, and 24x7 support.",
              telephone: "+91-123-456-7890",
              address: {
                "@type": "PostalAddress",
                streetAddress: "4th Floor, Skyline Towers, MG Road",
                addressLocality: "Bengaluru",
                addressCountry: "IN",
              },
              sameAs: [
                "https://instagram.com",
                "https://facebook.com",
                "https://twitter.com",
              ],
            }),
          }}
        />
        <ThemeProvider>
          <Navbar />
          <main>{children}</main>
          <Footer />
          <WhatsAppButton />
          <CallButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
