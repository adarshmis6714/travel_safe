import { LegalPage } from "@/components/ui/LegalPage";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Refund Policy",
  alternates: { canonical: "/refund-policy" },
};

export default function RefundPolicyPage() {
  return (
    <LegalPage title="Refund Policy" updated="July 1, 2026">
      <p>
        We know plans change. This policy outlines how cancellations and
        refunds are handled for bookings made through Travel Safe.
      </p>

      <h2>Cancellation Windows</h2>
      <ul>
        <li>30+ days before departure: full refund minus a processing fee.</li>
        <li>15–29 days before departure: 50% refund of the package cost.</li>
        <li>7–14 days before departure: 25% refund of the package cost.</li>
        <li>Less than 7 days before departure: non-refundable.</li>
      </ul>

      <h2>Non-Refundable Components</h2>
      <p>
        Certain components — including visa fees, travel insurance premiums,
        and non-refundable airline fares or hotel rates flagged at the time
        of booking — are excluded from refunds regardless of the
        cancellation window.
      </p>

      <h2>Refund Processing</h2>
      <p>
        Approved refunds are processed to the original payment method within
        7–10 business days of cancellation confirmation. Refund timelines
        may vary slightly depending on your bank or card issuer.
      </p>

      <h2>Rescheduling</h2>
      <p>
        Rescheduling requests made at least 15 days before departure are
        accommodated free of charge, subject to availability. Requests
        within 15 days may incur a rescheduling fee equivalent to the
        applicable cancellation charge.
      </p>

      <h2>How to Request a Refund</h2>
      <p>
        Email{" "}
        <a href="mailto:support@travelsafe.com">support@travelsafe.com</a>{" "}
        with your booking reference, or call your assigned coordinator
        directly, and we&apos;ll confirm the applicable refund amount within
        24 hours.
      </p>
    </LegalPage>
  );
}
