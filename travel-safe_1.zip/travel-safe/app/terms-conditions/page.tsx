import { LegalPage } from "@/components/ui/LegalPage";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  alternates: { canonical: "/terms-conditions" },
};

export default function TermsPage() {
  return (
    <LegalPage title="Terms & Conditions" updated="July 1, 2026">
      <p>
        These terms govern your use of the Travel Safe website and any
        booking made with Travel Safe Holidays Pvt. Ltd. By using our
        website or confirming a booking, you agree to the terms below.
      </p>

      <h2>Bookings & Payments</h2>
      <p>
        A booking is confirmed only once the applicable deposit or full
        payment is received and a confirmation is issued in writing.
        Package prices are subject to change until a booking is confirmed
        and may vary with currency fluctuations, fuel surcharges, or
        government taxes.
      </p>

      <h2>Traveller Responsibilities</h2>
      <ul>
        <li>Ensure passports are valid for at least six months beyond the return date.</li>
        <li>Obtain any visas, permits, or vaccinations required for your itinerary.</li>
        <li>Arrive at meeting points, airports, and check-ins at the times communicated by your coordinator.</li>
      </ul>

      <h2>Changes & Cancellations</h2>
      <p>
        Cancellation and rescheduling requests are handled per our{" "}
        <a href="/refund-policy">Refund Policy</a>. Travel Safe reserves the
        right to modify itineraries where necessary due to weather, safety,
        or operational reasons, and will offer a comparable alternative
        wherever possible.
      </p>

      <h2>Limitation of Liability</h2>
      <p>
        Travel Safe acts as an intermediary between travellers and third-party
        service providers (airlines, hotels, transport, and activity
        operators). While we vet our partners carefully, Travel Safe is not
        liable for delays, losses, or incidents caused directly by these
        third parties, except where required by law.
      </p>

      <h2>Governing Law</h2>
      <p>
        These terms are governed by the laws of India, and any disputes are
        subject to the exclusive jurisdiction of the courts of Bengaluru,
        Karnataka.
      </p>
    </LegalPage>
  );
}
