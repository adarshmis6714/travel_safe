import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { destinations, packages } from "@/lib/data";
import { formatINR } from "@/lib/utils";
import { BadgeCheck, CalendarDays, MapPin, Star } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";

export function generateStaticParams() {
  return packages.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const pkg = packages.find((p) => p.slug === slug);
  if (!pkg) return {};
  return {
    title: `${pkg.title} — ${formatINR(pkg.price)} | ${pkg.duration}`,
    description: pkg.overview,
    alternates: { canonical: `/packages/${pkg.slug}` },
    openGraph: { images: [{ url: pkg.image }] },
  };
}

export default async function PackageDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const pkg = packages.find((p) => p.slug === slug);
  if (!pkg) notFound();
  const destination = destinations.find((d) => d.slug === pkg.destinationSlug);

  return (
    <div className="pb-24 pt-28">
      <Container className="grid grid-cols-1 gap-10 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="relative h-80 w-full overflow-hidden rounded-3xl sm:h-96">
            <Image src={pkg.image} alt={pkg.title} fill sizes="(max-width:1024px) 100vw, 66vw" className="object-cover" priority />
            {pkg.discountPercent && (
              <span className="absolute left-4 top-4 rounded-full bg-primary px-3 py-1.5 text-xs font-bold text-white">
                {pkg.discountPercent}% OFF
              </span>
            )}
          </div>

          {destination && (
            <div className="mt-4 flex items-center gap-1.5 text-sm text-primary-900/60 dark:text-white/60">
              <MapPin size={14} />
              {destination.name}, {destination.country}
            </div>
          )}
          <h1 className="mt-2 text-3xl font-bold text-primary-900 sm:text-4xl dark:text-white">
            {pkg.title}
          </h1>
          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
            <span className="flex items-center gap-1 font-semibold text-primary-900 dark:text-white">
              <Star size={14} className="fill-accent text-accent" />
              {pkg.rating} ({pkg.reviews} reviews)
            </span>
            <span className="flex items-center gap-1 text-primary-900/60 dark:text-white/60">
              <CalendarDays size={14} />
              {pkg.duration}
            </span>
          </div>

          <p className="mt-6 leading-relaxed text-primary-900/70 dark:text-white/70">
            {pkg.overview}
          </p>

          <h2 className="mt-10 text-xl font-bold text-primary-900 dark:text-white">
            What&apos;s Included
          </h2>
          <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {pkg.inclusions.map((item) => (
              <li
                key={item}
                className="flex items-center gap-2.5 rounded-xl bg-secondary-50 px-4 py-3 text-sm text-secondary-800 dark:bg-white/5 dark:text-secondary-100"
              >
                <BadgeCheck size={16} className="flex-shrink-0" />
                {item}
              </li>
            ))}
          </ul>

          <h2 className="mt-10 text-xl font-bold text-primary-900 dark:text-white">
            Day-by-Day Itinerary
          </h2>
          <ol className="mt-6 space-y-6 border-l-2 border-primary-100 pl-6 dark:border-white/10">
            {pkg.itinerary.map((day) => (
              <li key={day.day} className="relative">
                <span className="absolute -left-[31px] flex h-6 w-6 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-white">
                  {day.day}
                </span>
                <h3 className="text-sm font-bold text-primary-900 dark:text-white">
                  Day {day.day}: {day.title}
                </h3>
                <p className="mt-1 text-sm text-primary-900/65 dark:text-white/65">
                  {day.description}
                </p>
              </li>
            ))}
          </ol>
        </div>

        <aside className="h-fit rounded-3xl border border-primary-900/5 bg-primary-50/50 p-6 shadow-card dark:border-white/10 dark:bg-primary-950 lg:sticky lg:top-28">
          {pkg.originalPrice && (
            <p className="text-sm text-primary-900/40 line-through dark:text-white/40">
              {formatINR(pkg.originalPrice)}
            </p>
          )}
          <p className="text-3xl font-bold text-primary-800 dark:text-white">
            {formatINR(pkg.price)}
            <span className="text-sm font-medium text-primary-900/50 dark:text-white/50"> / person</span>
          </p>
          <p className="mt-1 text-xs text-primary-900/50 dark:text-white/50">
            Taxes and fees included. No hidden charges.
          </p>

          <Button href={`/booking?package=${pkg.slug}`} className="mt-6 w-full justify-center">
            Book Now
          </Button>
          <Button href="/contact" variant="ghost" className="mt-3 w-full justify-center border border-primary-900/10 dark:border-white/15">
            Ask a Question
          </Button>

          <div className="mt-6 border-t border-primary-900/10 pt-4 text-xs text-primary-900/50 dark:border-white/10 dark:text-white/50">
            Free cancellation up to 7 days before departure. See our{" "}
            <a href="/refund-policy" className="underline">
              refund policy
            </a>
            .
          </div>
        </aside>
      </Container>
    </div>
  );
}
