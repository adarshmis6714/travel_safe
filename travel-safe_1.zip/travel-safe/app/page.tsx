import { BlogPreview } from "@/components/home/BlogPreview";
import { EnquirySection } from "@/components/home/EnquiryForm";
import { Gallery } from "@/components/home/Gallery";
import { Hero } from "@/components/home/Hero";
import { Newsletter } from "@/components/home/Newsletter";
import { PopularDestinations } from "@/components/home/PopularDestinations";
import { Stats } from "@/components/home/Stats";
import { Testimonials } from "@/components/home/Testimonials";
import { TravelCategories } from "@/components/home/TravelCategories";
import { TrendingPackages } from "@/components/home/TrendingPackages";
import { WhyChooseUs } from "@/components/home/WhyChooseUs";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Explore the World with Confidence",
  alternates: { canonical: "/" },
};

export default function HomePage() {
  return (
    <>
      <Hero />
      <div className="pt-16">
        <PopularDestinations />
      </div>
      <TrendingPackages />
      <WhyChooseUs />
      <TravelCategories />
      <Gallery />
      <Testimonials />
      <Stats />
      <BlogPreview />
      <EnquirySection />
      <Newsletter />
    </>
  );
}
