import { EnquirySection } from "@/components/home/EnquiryForm";
import { Container } from "@/components/ui/Container";
import { FileCheck2, Mail, MapPin, Phone } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Travel Safe for tour bookings, visa services, or custom itinerary planning.",
  alternates: { canonical: "/contact" },
};

const channels = [
  { icon: Phone, label: "Call Us", value: "+91 123 456 7890", href: "tel:+911234567890" },
  { icon: Mail, label: "Email Us", value: "hello@travelsafe.com", href: "mailto:hello@travelsafe.com" },
  { icon: MapPin, label: "Visit Us", value: "MG Road, Bengaluru, India", href: "https://maps.google.com" },
];

export default function ContactPage() {
  return (
    <div className="pb-8 pt-32">
      <Container className="max-w-2xl text-center">
        <span className="text-xs font-bold uppercase tracking-[0.2em] text-secondary-600 dark:text-secondary-300">
          Get in Touch
        </span>
        <h1 className="mt-3 text-3xl font-bold text-primary-900 sm:text-4xl dark:text-white">
          We usually reply within the hour
        </h1>
      </Container>

      <Container className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {channels.map((c) => (
          <a
            key={c.label}
            href={c.href}
            target={c.href.startsWith("http") ? "_blank" : undefined}
            rel="noopener noreferrer"
            className="flex items-center gap-4 rounded-2xl border border-primary-900/5 bg-primary-50/50 p-5 transition-colors hover:bg-primary-50 dark:border-white/10 dark:bg-primary-950 dark:hover:bg-white/5"
          >
            <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-primary text-white">
              <c.icon size={18} />
            </span>
            <div>
              <p className="text-xs text-primary-900/50 dark:text-white/50">{c.label}</p>
              <p className="text-sm font-semibold text-primary-900 dark:text-white">{c.value}</p>
            </div>
          </a>
        ))}
      </Container>

      <Container id="visa" className="mt-16 rounded-3xl bg-primary-950 p-8 text-white sm:p-10">
        <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-4">
            <span className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-white/10 text-secondary-300">
              <FileCheck2 size={22} />
            </span>
            <div>
              <h2 className="text-lg font-bold">Visa Services</h2>
              <p className="mt-1 max-w-lg text-sm text-white/65">
                Document checklists, appointment scheduling, and application
                tracking for tourist visas to Thailand, UAE, Schengen, and 40+
                other destinations.
              </p>
            </div>
          </div>
          <a
            href="tel:+911234567890"
            className="flex-shrink-0 rounded-full bg-secondary px-6 py-3 text-sm font-bold text-primary-900"
          >
            Talk to Visa Desk
          </a>
        </div>
      </Container>

      <div className="mt-10 h-72 w-full overflow-hidden">
        <iframe
          title="Travel Safe office location"
          src="https://www.google.com/maps?q=MG%20Road%2C%20Bengaluru&output=embed"
          className="h-full w-full border-0"
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      </div>

      <EnquirySection />
    </div>
  );
}
