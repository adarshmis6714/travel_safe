import { Container } from "@/components/ui/Container";
import { DestinationCard } from "@/components/ui/DestinationCard";
import { destinations, travelCategories } from "@/lib/data";
import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Tour Packages — International, Domestic & Honeymoon",
  description:
    "Browse Travel Safe's handpicked tour packages across Thailand, Bali, Dubai, Maldives, Europe, Kashmir, Goa, Kerala and more.",
  alternates: { canonical: "/destinations" },
};

const domesticSlugs = ["kashmir", "goa", "kerala", "andaman"];

export default async function DestinationsPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | undefined }>;
}) {
  const params = await searchParams;
  const q = params.q?.toLowerCase();
  const type = params.type;
  const category = params.category;

  let list = destinations;

  if (q) {
    list = list.filter(
      (d) =>
        d.name.toLowerCase().includes(q) || d.country.toLowerCase().includes(q)
    );
  }
  if (type === "domestic") {
    list = list.filter((d) => domesticSlugs.includes(d.slug));
  } else if (type === "international") {
    list = list.filter((d) => !domesticSlugs.includes(d.slug));
  }

  const categoryLabel = travelCategories.find((c) => c.slug === category)?.name;

  return (
    <div className="pb-24 pt-32">
      <Container>
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-secondary-600 dark:text-secondary-300">
            {categoryLabel ? `${categoryLabel} Tours` : "All Destinations"}
          </span>
          <h1 className="mt-3 text-3xl font-bold text-primary-900 sm:text-4xl dark:text-white">
            {q ? `Results for "${params.q}"` : "Find your next trip"}
          </h1>
          <p className="mt-3 text-primary-900/60 dark:text-white/60">
            {list.length} destination{list.length !== 1 ? "s" : ""} handpicked and
            safety-scored by our travel experts.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          <FilterPill href="/destinations" label="All" active={!type && !category}
          />
          <FilterPill href="/destinations?type=international" label="International" active={type === "international"} />
          <FilterPill href="/destinations?type=domestic" label="Domestic" active={type === "domestic"} />
          {travelCategories.slice(0, 4).map((c) => (
            <FilterPill
              key={c.slug}
              href={`/destinations?category=${c.slug}`}
              label={c.name}
              active={category === c.slug}
            />
          ))}
        </div>

        {list.length > 0 ? (
          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((d, i) => (
              <DestinationCard key={d.slug} destination={d} index={i} />
            ))}
          </div>
        ) : (
          <div className="mt-16 rounded-3xl border border-dashed border-primary-900/15 py-20 text-center dark:border-white/15">
            <p className="text-primary-900/60 dark:text-white/60">
              No destinations matched your search. Try browsing all destinations instead.
            </p>
            <Link
              href="/destinations"
              className="mt-4 inline-block text-sm font-semibold text-secondary-600 dark:text-secondary-300"
            >
              Clear filters
            </Link>
          </div>
        )}
      </Container>
    </div>
  );
}

function FilterPill({
  href,
  label,
  active,
}: {
  href: string;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      href={href}
      className={`rounded-full px-4 py-2 text-xs font-semibold transition-colors ${
        active
          ? "bg-primary text-white"
          : "bg-primary-50 text-primary-700 hover:bg-primary-100 dark:bg-white/10 dark:text-white/70"
      }`}
    >
      {label}
    </Link>
  );
}
