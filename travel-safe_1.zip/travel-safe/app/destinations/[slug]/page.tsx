import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { PackageCard } from "@/components/ui/PackageCard";
import { SafetyBadge } from "@/components/ui/SafetyBadge";
import { destinations, packages } from "@/lib/data";
import { formatINR } from "@/lib/utils";
import { CalendarDays, CheckCircle2, Clock, MapPin, Star } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";

export function generateStaticParams() {
  return destinations.map((d) => ({ slug: d.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const destination = destinations.find((d) => d.slug === slug);
  if (!destination) return {};
  return {
    title: `${destination.name} Tour Packages — Starting ${formatINR(destination.startingPrice)}`,
    description: destination.description,
    alternates: { canonical: `/destinations/${destination.slug}` },
    openGraph: {
      images: [{ url: destination.image }],
    },
  };
}

export default async function DestinationDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const destination = destinations.find((d) => d.slug === slug);
  if (!destination) notFound();

  const relatedPackages = packages.filter((p) => p.destinationSlug === slug);

  return (
    <div className="pb-24">
      <section className="relative h-[60vh] min-h-[420px] w-full">
        <Image
          src={destination.image}
          alt={destination.name}
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary-950 via-primary-950/40 to-primary-950/10" />
        <Container className="relative flex h-full flex-col justify-end pb-10 pt-32">
          <div className="flex items-center gap-2 text-white/70">
            <MapPin size={14} />
            <span className="text-sm">{destination.country}</span>
          </div>
          <h1 className="mt-2 text-4xl font-bold text-white sm:text-5xl">
            {destination.name}
          </h1>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-sm">
              <Star size={13} className="fill-accent text-accent" />
              {destination.rating} ({destination.reviews} reviews)
            </span>
            <span className="flex items-center gap-1 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-sm">
              <Clock size={13} />
              {destination.duration}
            </span>
            <SafetyBadge score={destination.safetyScore} className="bg-white/10 text-white" />
          </div>
        </Container>
      </section>

      <Container className="mt-12 grid grid-cols-1 gap-12 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <h2 className="text-xl font-bold text-primary-900 dark:text-white">
            About {destination.name}
          </h2>
          <p className="mt-3 leading-relaxed text-primary-900/70 dark:text-white/70">
            {destination.description}
          </p>

          <h3 className="mt-8 text-lg font-bold text-primary-900 dark:text-white">
            Trip Highlights
          </h3>
          <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {destination.highlights.map((h) => (
              <li
                key={h}
                className="flex items-center gap-2.5 rounded-xl bg-primary-50/70 px-4 py-3 text-sm text-primary-900/80 dark:bg-white/5 dark:text-white/80"
              >
                <CheckCircle2 size={16} className="flex-shrink-0 text-secondary-600 dark:text-secondary-300" />
                {h}
              </li>
            ))}
          </ul>

          {relatedPackages.length > 0 && (
            <div className="mt-12">
              <h3 className="text-lg font-bold text-primary-900 dark:text-white">
                Packages for {destination.name}
              </h3>
              <div className="mt-5 grid grid-cols-1 gap-6">
                {relatedPackages.map((pkg, i) => (
                  <PackageCard key={pkg.slug} pkg={pkg} index={i} />
                ))}
              </div>
            </div>
          )}
        </div>

        <aside className="h-fit rounded-3xl border border-primary-900/5 bg-primary-50/50 p-6 shadow-card dark:border-white/10 dark:bg-primary-950">
          <p className="text-xs uppercase tracking-wide text-primary-900/50 dark:text-white/50">
            Starting from
          </p>
          <p className="mt-1 text-3xl font-bold text-primary-800 dark:text-white">
            {formatINR(destination.startingPrice)}
            <span className="text-sm font-medium text-primary-900/50 dark:text-white/50"> / person</span>
          </p>

          <ul className="mt-5 space-y-3 text-sm text-primary-900/70 dark:text-white/70">
            <li className="flex items-center gap-2.5">
              <CalendarDays size={16} className="text-secondary-600 dark:text-secondary-300" />
              Best time to visit: {destination.bestTime}
            </li>
            <li className="flex items-center gap-2.5">
              <Clock size={16} className="text-secondary-600 dark:text-secondary-300" />
              Typical duration: {destination.duration}
            </li>
          </ul>

          <Button href="/contact" className="mt-6 w-full justify-center">
            Enquire Now
          </Button>
          <Button href="/booking" variant="ghost" className="mt-3 w-full justify-center border border-primary-900/10 dark:border-white/15">
            Book This Trip
          </Button>
        </aside>
      </Container>
    </div>
  );
}
