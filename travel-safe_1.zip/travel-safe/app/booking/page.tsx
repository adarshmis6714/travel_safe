"use client";

import { Container } from "@/components/ui/Container";
import { packages } from "@/lib/data";
import { formatINR } from "@/lib/utils";
import { CheckCircle2, ShieldCheck } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";

function BookingForm() {
  const searchParams = useSearchParams();
  const preselected = searchParams.get("package");
  const pkg = packages.find((p) => p.slug === preselected) ?? packages[0];
  const [submitted, setSubmitted] = useState(false);
  const [travellers, setTravellers] = useState(2);

  return (
    <div className="pb-24 pt-32">
      <Container className="grid grid-cols-1 gap-10 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-secondary-600 dark:text-secondary-300">
            Secure Booking
          </span>
          <h1 className="mt-2 text-3xl font-bold text-primary-900 dark:text-white">
            Complete your booking
          </h1>

          {submitted ? (
            <div className="mt-10 flex flex-col items-center rounded-3xl border border-primary-900/5 bg-primary-50/50 p-10 text-center shadow-card dark:border-white/10 dark:bg-primary-950">
              <CheckCircle2 size={40} className="text-secondary-600 dark:text-secondary-300" />
              <h2 className="mt-4 text-xl font-bold text-primary-900 dark:text-white">
                Booking request received
              </h2>
              <p className="mt-2 max-w-sm text-sm text-primary-900/60 dark:text-white/60">
                A Travel Safe coordinator will call you within the hour to confirm dates and take payment securely.
              </p>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSubmitted(true);
              }}
              className="mt-8 space-y-6 rounded-3xl border border-primary-900/5 bg-primary-50/50 p-6 shadow-card sm:p-8 dark:border-white/10 dark:bg-primary-950"
            >
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Full Name" name="name" required />
                <Field label="Phone Number" name="phone" type="tel" required />
                <Field label="Email Address" name="email" type="email" required className="sm:col-span-2" />
                <Field label="Preferred Travel Date" name="date" type="date" />
                <label className="flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70">
                  Number of Travellers
                  <input
                    type="number"
                    min={1}
                    value={travellers}
                    onChange={(e) => setTravellers(Number(e.target.value) || 1)}
                    className="rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white"
                  />
                </label>
              </div>

              <label className="flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70">
                Special Requests
                <textarea
                  rows={3}
                  placeholder="Room preferences, dietary needs, celebrations..."
                  className="resize-none rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 placeholder:text-primary-900/40 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white"
                />
              </label>

              <button
                type="submit"
                className="w-full rounded-full bg-primary px-6 py-4 text-sm font-bold text-white transition-colors hover:bg-primary-600"
              >
                Confirm Booking Request
              </button>
              <p className="flex items-center gap-2 text-xs text-primary-900/50 dark:text-white/50">
                <ShieldCheck size={14} className="text-secondary-600 dark:text-secondary-300" />
                Encrypted &amp; secure. No payment is taken until your itinerary is confirmed.
              </p>
            </form>
          )}
        </div>

        <aside className="h-fit rounded-3xl border border-primary-900/5 bg-white p-6 shadow-card lg:col-span-2 dark:border-white/10 dark:bg-ink">
          <h2 className="text-sm font-bold uppercase tracking-wide text-primary-900/60 dark:text-white/60">
            Order Summary
          </h2>
          <div className="mt-4 flex items-center justify-between">
            <p className="font-semibold text-primary-900 dark:text-white">{pkg.title}</p>
          </div>
          <p className="mt-1 text-xs text-primary-900/50 dark:text-white/50">{pkg.duration}</p>

          <div className="mt-5 space-y-2 border-t border-primary-900/10 pt-4 text-sm dark:border-white/10">
            <div className="flex justify-between text-primary-900/70 dark:text-white/70">
              <span>Price per person</span>
              <span>{formatINR(pkg.price)}</span>
            </div>
            <div className="flex justify-between text-primary-900/70 dark:text-white/70">
              <span>Travellers</span>
              <span>× {travellers}</span>
            </div>
          </div>
          <div className="mt-4 flex justify-between border-t border-primary-900/10 pt-4 text-lg font-bold text-primary-900 dark:border-white/10 dark:text-white">
            <span>Estimated Total</span>
            <span>{formatINR(pkg.price * travellers)}</span>
          </div>
        </aside>
      </Container>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  required,
  className,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  className?: string;
}) {
  return (
    <label className={`flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70 ${className ?? ""}`}>
      {label}
      <input
        name={name}
        type={type}
        required={required}
        className="rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white"
      />
    </label>
  );
}

export default function BookingPage() {
  return (
    <Suspense fallback={<div className="pt-40 text-center">Loading...</div>}>
      <BookingForm />
    </Suspense>
  );
}
