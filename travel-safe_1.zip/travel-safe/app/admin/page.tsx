"use client";

import { Container } from "@/components/ui/Container";
import { packages as seedPackages, blogPosts as seedBlogs, stats } from "@/lib/data";
import { formatINR } from "@/lib/utils";
import {
  BarChart3,
  FileText,
  Inbox,
  LayoutDashboard,
  Package,
  Plus,
  Trash2,
} from "lucide-react";
import { useState } from "react";

type Tab = "overview" | "packages" | "blogs" | "enquiries";

interface Enquiry {
  id: string;
  name: string;
  destination: string;
  phone: string;
  status: "New" | "Contacted" | "Converted";
}

const seedEnquiries: Enquiry[] = [
  { id: "1", name: "Ananya Rao", destination: "Maldives", phone: "+91 98xxxxxx21", status: "New" },
  { id: "2", name: "Rohan Malhotra", destination: "Europe", phone: "+91 87xxxxxx45", status: "Contacted" },
  { id: "3", name: "Priya Menon", destination: "Bali", phone: "+91 99xxxxxx02", status: "Converted" },
  { id: "4", name: "Sameer Khan", destination: "Thailand", phone: "+91 91xxxxxx77", status: "New" },
];

const tabs: { key: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { key: "overview", label: "Dashboard", icon: LayoutDashboard },
  { key: "packages", label: "Packages", icon: Package },
  { key: "blogs", label: "Blogs", icon: FileText },
  { key: "enquiries", label: "Enquiries", icon: Inbox },
];

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>("overview");
  const [packages, setPackages] = useState(seedPackages);
  const [blogs, setBlogs] = useState(seedBlogs);
  const [enquiries, setEnquiries] = useState(seedEnquiries);

  return (
    <div className="min-h-screen bg-primary-50/40 pb-24 pt-28 dark:bg-primary-950/60">
      <Container>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-primary-900 dark:text-white">
              Travel Safe Admin
            </h1>
            <p className="mt-1 text-sm text-primary-900/55 dark:text-white/55">
              Internal dashboard preview — connect to your API to persist changes.
            </p>
          </div>
        </div>

        <div className="mt-8 flex gap-2 overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 whitespace-nowrap rounded-full px-4 py-2.5 text-sm font-semibold transition-colors ${
                tab === t.key
                  ? "bg-primary text-white"
                  : "bg-white text-primary-900/70 hover:bg-primary-50 dark:bg-primary-900 dark:text-white/70"
              }`}
            >
              <t.icon size={15} />
              {t.label}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {tab === "overview" && <Overview />}
          {tab === "packages" && (
            <PackagesTab
              packages={packages}
              onDelete={(slug) => setPackages((p) => p.filter((x) => x.slug !== slug))}
            />
          )}
          {tab === "blogs" && (
            <BlogsTab blogs={blogs} onDelete={(slug) => setBlogs((b) => b.filter((x) => x.slug !== slug))} />
          )}
          {tab === "enquiries" && (
            <EnquiriesTab
              enquiries={enquiries}
              onStatusChange={(id, status) =>
                setEnquiries((list) => list.map((e) => (e.id === id ? { ...e, status } : e)))
              }
            />
          )}
        </div>
      </Container>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-3xl border border-primary-900/5 bg-white p-6 shadow-card dark:border-white/10 dark:bg-ink">
      {children}
    </div>
  );
}

function Overview() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <p className="text-xs font-medium uppercase tracking-wide text-primary-900/50 dark:text-white/50">
              {s.label}
            </p>
            <p className="mt-2 text-2xl font-bold text-primary-900 dark:text-white">
              {s.value.toLocaleString("en-IN")}
              {s.suffix}
            </p>
          </Card>
        ))}
      </div>

      <Card>
        <div className="flex items-center gap-2">
          <BarChart3 size={16} className="text-secondary-600 dark:text-secondary-300" />
          <h2 className="text-sm font-bold text-primary-900 dark:text-white">
            Enquiries by destination (last 30 days)
          </h2>
        </div>
        <div className="mt-6 space-y-4">
          {[
            { label: "Maldives", value: 82 },
            { label: "Bali", value: 71 },
            { label: "Europe", value: 64 },
            { label: "Thailand", value: 58 },
            { label: "Dubai", value: 49 },
          ].map((row) => (
            <div key={row.label}>
              <div className="mb-1.5 flex justify-between text-xs font-medium text-primary-900/60 dark:text-white/60">
                <span>{row.label}</span>
                <span>{row.value}</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-primary-50 dark:bg-white/10">
                <div
                  className="h-full rounded-full bg-secondary"
                  style={{ width: `${row.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function PackagesTab({
  packages,
  onDelete,
}: {
  packages: typeof seedPackages;
  onDelete: (slug: string) => void;
}) {
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-primary-900 dark:text-white">
          {packages.length} Packages
        </h2>
        <button className="flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-bold text-white">
          <Plus size={14} /> Add Package
        </button>
      </div>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead>
            <tr className="border-b border-primary-900/10 text-xs uppercase tracking-wide text-primary-900/45 dark:border-white/10 dark:text-white/45">
              <th className="py-3">Title</th>
              <th className="py-3">Category</th>
              <th className="py-3">Price</th>
              <th className="py-3">Rating</th>
              <th className="py-3" />
            </tr>
          </thead>
          <tbody>
            {packages.map((p) => (
              <tr key={p.slug} className="border-b border-primary-900/5 dark:border-white/5">
                <td className="py-3 font-medium text-primary-900 dark:text-white">{p.title}</td>
                <td className="py-3 text-primary-900/60 dark:text-white/60">{p.category}</td>
                <td className="py-3 text-primary-900/60 dark:text-white/60">{formatINR(p.price)}</td>
                <td className="py-3 text-primary-900/60 dark:text-white/60">{p.rating}</td>
                <td className="py-3 text-right">
                  <button
                    onClick={() => onDelete(p.slug)}
                    aria-label={`Delete ${p.title}`}
                    className="text-primary-900/40 hover:text-red-500 dark:text-white/40"
                  >
                    <Trash2 size={15} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function BlogsTab({
  blogs,
  onDelete,
}: {
  blogs: typeof seedBlogs;
  onDelete: (slug: string) => void;
}) {
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold text-primary-900 dark:text-white">
          {blogs.length} Blog Posts
        </h2>
        <button className="flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-bold text-white">
          <Plus size={14} /> Add Blog Post
        </button>
      </div>
      <div className="mt-4 divide-y divide-primary-900/5 dark:divide-white/5">
        {blogs.map((b) => (
          <div key={b.slug} className="flex items-center justify-between py-3">
            <div>
              <p className="text-sm font-medium text-primary-900 dark:text-white">{b.title}</p>
              <p className="text-xs text-primary-900/50 dark:text-white/50">
                {b.category} &middot; {b.readTime}
              </p>
            </div>
            <button
              onClick={() => onDelete(b.slug)}
              aria-label={`Delete ${b.title}`}
              className="text-primary-900/40 hover:text-red-500 dark:text-white/40"
            >
              <Trash2 size={15} />
            </button>
          </div>
        ))}
      </div>
    </Card>
  );
}

function EnquiriesTab({
  enquiries,
  onStatusChange,
}: {
  enquiries: Enquiry[];
  onStatusChange: (id: string, status: Enquiry["status"]) => void;
}) {
  return (
    <Card>
      <h2 className="text-sm font-bold text-primary-900 dark:text-white">
        {enquiries.length} Enquiries
      </h2>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead>
            <tr className="border-b border-primary-900/10 text-xs uppercase tracking-wide text-primary-900/45 dark:border-white/10 dark:text-white/45">
              <th className="py-3">Name</th>
              <th className="py-3">Destination</th>
              <th className="py-3">Phone</th>
              <th className="py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {enquiries.map((e) => (
              <tr key={e.id} className="border-b border-primary-900/5 dark:border-white/5">
                <td className="py-3 font-medium text-primary-900 dark:text-white">{e.name}</td>
                <td className="py-3 text-primary-900/60 dark:text-white/60">{e.destination}</td>
                <td className="py-3 text-primary-900/60 dark:text-white/60">{e.phone}</td>
                <td className="py-3">
                  <select
                    value={e.status}
                    onChange={(ev) => onStatusChange(e.id, ev.target.value as Enquiry["status"])}
                    className="rounded-full border border-primary-900/10 bg-white px-3 py-1.5 text-xs font-semibold text-primary-900 dark:border-white/15 dark:bg-primary-900 dark:text-white"
                  >
                    <option>New</option>
                    <option>Contacted</option>
                    <option>Converted</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
