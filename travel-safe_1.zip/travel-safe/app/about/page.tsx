import { Container } from "@/components/ui/Container";
import { Counter } from "@/components/ui/Counter";
import { stats } from "@/lib/data";
import { Heart, ShieldCheck, Sparkles, Target } from "lucide-react";
import type { Metadata } from "next";
import Image from "next/image";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Travel Safe is a trust-first travel company designing handpicked itineraries backed by verified stays and 24x7 support.",
  alternates: { canonical: "/about" },
};

const values = [
  {
    icon: ShieldCheck,
    title: "Safety First",
    description: "Every hotel, driver, and activity partner is vetted before it enters an itinerary.",
  },
  {
    icon: Heart,
    title: "Genuine Care",
    description: "Coordinators who answer the phone, not chatbots that read from a script.",
  },
  {
    icon: Target,
    title: "Fair Pricing",
    description: "One quoted price, no add-on surprises when you check out.",
  },
  {
    icon: Sparkles,
    title: "Thoughtful Design",
    description: "Itineraries paced for how people actually travel, not how spreadsheets look.",
  },
];

export default function AboutPage() {
  return (
    <div className="pb-24 pt-32">
      <Container className="max-w-3xl text-center">
        <span className="text-xs font-bold uppercase tracking-[0.2em] text-secondary-600 dark:text-secondary-300">
          About Travel Safe
        </span>
        <h1 className="mt-3 text-3xl font-bold text-primary-900 sm:text-4xl dark:text-white">
          Built by travellers who got tired of surprises
        </h1>
        <p className="mt-4 leading-relaxed text-primary-900/65 dark:text-white/65">
          Travel Safe started with a simple frustration: too many trips were
          being sold on price alone, with the fine print sorted out after
          booking. We set out to build a travel company where the itinerary
          you see is the itinerary you get — verified hotels, transparent
          costs, and a team that stays reachable long after the booking
          confirmation lands in your inbox.
        </p>
      </Container>

      <div className="relative mt-14 h-72 w-full overflow-hidden sm:h-96">
        <Image
          src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?q=80&w=2000&auto=format&fit=crop"
          alt="Travel Safe team planning an itinerary"
          fill
          sizes="100vw"
          className="object-cover"
        />
      </div>

      <Container className="mt-16 grid grid-cols-2 gap-8 sm:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="text-center">
            <p className="text-3xl font-bold text-primary-800 dark:text-white">
              <Counter value={s.value} suffix={s.suffix} />
            </p>
            <p className="mt-2 text-xs font-medium uppercase tracking-wide text-primary-900/50 dark:text-white/50">
              {s.label}
            </p>
          </div>
        ))}
      </Container>

      <Container className="mt-20">
        <h2 className="text-center text-2xl font-bold text-primary-900 dark:text-white">
          What we stand for
        </h2>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v) => (
            <div
              key={v.title}
              className="rounded-3xl border border-primary-900/5 bg-primary-50/50 p-6 dark:border-white/10 dark:bg-primary-950"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary-50 text-primary dark:bg-white/10 dark:text-secondary-300">
                <v.icon size={20} />
              </span>
              <h3 className="mt-4 text-sm font-bold text-primary-900 dark:text-white">
                {v.title}
              </h3>
              <p className="mt-1.5 text-xs leading-relaxed text-primary-900/60 dark:text-white/60">
                {v.description}
              </p>
            </div>
          ))}
        </div>
      </Container>

      <Container id="careers" className="mt-20 rounded-3xl bg-primary-950 p-10 text-center text-white">
        <h2 className="text-xl font-bold">Careers at Travel Safe</h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-white/65">
          We're always looking for destination specialists and support
          coordinators who care about getting the details right. Write to us
          at{" "}
          <a href="mailto:careers@travelsafe.com" className="underline">
            careers@travelsafe.com
          </a>
          .
        </p>
      </Container>
    </div>
  );
}
