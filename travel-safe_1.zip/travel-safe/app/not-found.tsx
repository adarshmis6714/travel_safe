import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { Compass } from "lucide-react";

export default function NotFound() {
  return (
    <Container className="flex min-h-[70vh] flex-col items-center justify-center pt-24 text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-full bg-primary-50 text-primary dark:bg-white/10 dark:text-secondary-300">
        <Compass size={28} />
      </span>
      <h1 className="mt-6 text-3xl font-bold text-primary-900 dark:text-white">
        Looks like you&apos;ve wandered off the map
      </h1>
      <p className="mt-3 max-w-md text-primary-900/60 dark:text-white/60">
        The page you&apos;re looking for doesn&apos;t exist. Let&apos;s get
        you back to planning your next trip.
      </p>
      <Button href="/" className="mt-6">
        Back to Home
      </Button>
    </Container>
  );
}
