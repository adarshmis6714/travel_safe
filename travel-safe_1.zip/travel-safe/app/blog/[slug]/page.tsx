import { Container } from "@/components/ui/Container";
import { blogPosts } from "@/lib/data";
import type { Metadata } from "next";
import { CalendarDays, Clock, User } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

export function generateStaticParams() {
  return blogPosts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) return {};
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: { images: [{ url: post.image }] },
  };
}

export default async function BlogDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) notFound();
  const related = blogPosts.filter((p) => p.slug !== slug).slice(0, 3);

  return (
    <article className="pb-24 pt-32">
      <Container className="max-w-3xl">
        <span className="rounded-full bg-accent px-3 py-1 text-[11px] font-bold uppercase text-primary-900">
          {post.category}
        </span>
        <h1 className="mt-4 text-3xl font-bold leading-tight text-primary-900 sm:text-4xl dark:text-white">
          {post.title}
        </h1>
        <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-primary-900/55 dark:text-white/55">
          <span className="flex items-center gap-1.5">
            <User size={14} /> {post.author}
          </span>
          <span className="flex items-center gap-1.5">
            <CalendarDays size={14} />
            {new Date(post.date).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}
          </span>
          <span className="flex items-center gap-1.5">
            <Clock size={14} /> {post.readTime}
          </span>
        </div>

        <div className="relative mt-8 h-72 w-full overflow-hidden rounded-3xl sm:h-96">
          <Image src={post.image} alt={post.title} fill sizes="(max-width:768px) 100vw, 768px" className="object-cover" priority />
        </div>

        <div className="prose prose-lg mt-8 max-w-none text-primary-900/75 dark:text-white/75">
          <p className="leading-relaxed">{post.content}</p>
        </div>
      </Container>

      {related.length > 0 && (
        <Container className="mt-16">
          <h2 className="text-xl font-bold text-primary-900 dark:text-white">
            More from the journal
          </h2>
          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-3">
            {related.map((p) => (
              <Link
                key={p.slug}
                href={`/blog/${p.slug}`}
                className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-card transition-shadow hover:shadow-card-hover dark:bg-primary-950"
              >
                <div className="relative h-36 w-full overflow-hidden">
                  <Image src={p.image} alt={p.title} fill sizes="33vw" className="object-cover transition-transform duration-700 group-hover:scale-110" />
                </div>
                <div className="p-4">
                  <h3 className="line-clamp-2 text-sm font-bold text-primary-900 dark:text-white">
                    {p.title}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </Container>
      )}
    </article>
  );
}
