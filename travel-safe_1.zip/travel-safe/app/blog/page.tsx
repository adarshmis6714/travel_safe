import { Container } from "@/components/ui/Container";
import { blogPosts } from "@/lib/data";
import type { Metadata } from "next";
import { ArrowRight } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Travel Blog — Tips, Guides & Visa Advice",
  description:
    "Practical travel tips, destination guides, and visa know-how from the Travel Safe team.",
  alternates: { canonical: "/blog" },
};

export default function BlogPage() {
  const [featured, ...rest] = blogPosts;

  return (
    <div className="pb-24 pt-32">
      <Container>
        <span className="text-xs font-bold uppercase tracking-[0.2em] text-secondary-600 dark:text-secondary-300">
          The Journal
        </span>
        <h1 className="mt-2 text-3xl font-bold text-primary-900 sm:text-4xl dark:text-white">
          Travel tips, guides &amp; visa know-how
        </h1>

        <Link
          href={`/blog/${featured.slug}`}
          className="group mt-10 grid grid-cols-1 gap-6 overflow-hidden rounded-3xl bg-primary-50/50 shadow-card md:grid-cols-2 dark:bg-primary-950"
        >
          <div className="relative h-64 w-full md:h-full">
            <Image src={featured.image} alt={featured.title} fill sizes="(max-width:768px) 100vw, 50vw" className="object-cover transition-transform duration-700 group-hover:scale-105" />
          </div>
          <div className="flex flex-col justify-center p-6 sm:p-8">
            <span className="w-fit rounded-full bg-accent px-3 py-1 text-[11px] font-bold uppercase text-primary-900">
              {featured.category}
            </span>
            <h2 className="mt-4 text-2xl font-bold text-primary-900 dark:text-white">
              {featured.title}
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-primary-900/60 dark:text-white/60">
              {featured.excerpt}
            </p>
            <div className="mt-5 flex items-center gap-3 text-xs text-primary-900/50 dark:text-white/50">
              <span>{featured.author}</span>
              <span>&middot;</span>
              <span>{featured.readTime}</span>
            </div>
          </div>
        </Link>

        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {rest.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-card transition-shadow hover:shadow-card-hover dark:bg-primary-950"
            >
              <div className="relative h-44 w-full overflow-hidden">
                <Image src={post.image} alt={post.title} fill sizes="(max-width:768px) 100vw, 33vw" className="object-cover transition-transform duration-700 group-hover:scale-110" />
                <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-primary-800">
                  {post.category}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="text-base font-bold leading-snug text-primary-900 dark:text-white">
                  {post.title}
                </h3>
                <p className="mt-2 line-clamp-2 flex-1 text-sm text-primary-900/55 dark:text-white/55">
                  {post.excerpt}
                </p>
                <div className="mt-4 flex items-center justify-between border-t border-primary-900/5 pt-3 text-xs text-primary-900/45 dark:border-white/10 dark:text-white/45">
                  <span>{post.readTime}</span>
                  <span className="flex items-center gap-1 font-semibold text-secondary-600 dark:text-secondary-300">
                    Read <ArrowRight size={12} />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </Container>
    </div>
  );
}
