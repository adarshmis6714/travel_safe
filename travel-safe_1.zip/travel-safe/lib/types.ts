export interface Destination {
  slug: string;
  name: string;
  country: string;
  image: string;
  gallery: string[];
  startingPrice: number;
  duration: string;
  rating: number;
  reviews: number;
  tag?: string;
  description: string;
  highlights: string[];
  bestTime: string;
  safetyScore: number;
}

export interface TourPackage {
  slug: string;
  title: string;
  destinationSlug: string;
  image: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  duration: string;
  nights: number;
  days: number;
  inclusions: string[];
  category: TravelCategory;
  rating: number;
  reviews: number;
  overview: string;
  itinerary: { day: number; title: string; description: string }[];
}

export type TravelCategory =
  | "Family"
  | "Honeymoon"
  | "Adventure"
  | "Luxury"
  | "Group"
  | "Corporate"
  | "Weekend";

export interface Testimonial {
  name: string;
  location: string;
  image: string;
  rating: number;
  review: string;
  trip: string;
}

export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  content: string;
}

export interface StatItem {
  label: string;
  value: number;
  suffix: string;
}
