import {
  BlogPost,
  Destination,
  StatItem,
  Testimonial,
  TourPackage,
} from "./types";

export const destinations: Destination[] = [
  {
    slug: "thailand",
    name: "Thailand",
    country: "Southeast Asia",
    image:
      "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1508009603885-50cf7c579365?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 34999,
    duration: "6D/5N",
    rating: 4.8,
    reviews: 612,
    tag: "Trending",
    description:
      "Golden temples, island beaches, and street-food nights across Bangkok, Phuket, and Krabi.",
    highlights: ["Phi Phi Islands cruise", "Bangkok temple trail", "Phuket beach resorts"],
    bestTime: "Nov – Feb",
    safetyScore: 96,
  },
  {
    slug: "bali",
    name: "Bali",
    country: "Indonesia",
    image:
      "https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 38999,
    duration: "5D/4N",
    rating: 4.9,
    reviews: 845,
    tag: "Bestseller",
    description:
      "Rice-terrace sunrises, cliffside temples, and private-pool villas in Ubud and Seminyak.",
    highlights: ["Ubud rice terraces", "Uluwatu cliff temple", "Private villa stay"],
    bestTime: "Apr – Oct",
    safetyScore: 95,
  },
  {
    slug: "dubai",
    name: "Dubai",
    country: "United Arab Emirates",
    image:
      "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 42999,
    duration: "5D/4N",
    rating: 4.8,
    reviews: 723,
    tag: "Luxury",
    description:
      "Desert safaris, record-breaking skylines, and five-star indulgence in the Gulf's boldest city.",
    highlights: ["Burj Khalifa At The Top", "Desert safari dinner", "Dhow marina cruise"],
    bestTime: "Nov – Mar",
    safetyScore: 98,
  },
  {
    slug: "maldives",
    name: "Maldives",
    country: "Indian Ocean",
    image:
      "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 64999,
    duration: "4D/3N",
    rating: 4.9,
    reviews: 401,
    tag: "Honeymoon Special",
    description:
      "Overwater villas, glass-clear lagoons, and private sandbank dinners for two.",
    highlights: ["Overwater villa stay", "Sunset dolphin cruise", "Private sandbank dinner"],
    bestTime: "Dec – Apr",
    safetyScore: 97,
  },
  {
    slug: "europe",
    name: "Europe",
    country: "Multi-country",
    image:
      "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 129999,
    duration: "10D/9N",
    rating: 4.9,
    reviews: 358,
    tag: "Grand Tour",
    description:
      "Paris boulevards, Swiss peaks, and Italian piazzas on one seamless multi-country itinerary.",
    highlights: ["Eiffel Tower dinner cruise", "Swiss Alps cable car", "Venice gondola ride"],
    bestTime: "May – Sep",
    safetyScore: 97,
  },
  {
    slug: "vietnam",
    name: "Vietnam",
    country: "Southeast Asia",
    image:
      "https://images.unsplash.com/photo-1528127269322-539801943592?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1528127269322-539801943592?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1509923074449-1bf42303a279?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 32999,
    duration: "6D/5N",
    rating: 4.7,
    reviews: 287,
    tag: "Value Pick",
    description:
      "Ha Long Bay cruises, lantern-lit old towns, and misty mountain rail rides.",
    highlights: ["Ha Long Bay overnight cruise", "Hoi An lantern town", "Sapa terraces"],
    bestTime: "Mar – May",
    safetyScore: 94,
  },
  {
    slug: "kashmir",
    name: "Kashmir",
    country: "India",
    image:
      "https://images.unsplash.com/photo-1566837945700-30057527ade0?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1566837945700-30057527ade0?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 21999,
    duration: "6D/5N",
    rating: 4.8,
    reviews: 519,
    tag: "Paradise on Earth",
    description:
      "Houseboats on Dal Lake, snow-capped Gulmarg, and saffron fields of Pahalgam.",
    highlights: ["Dal Lake houseboat", "Gulmarg gondola", "Pahalgam valley drive"],
    bestTime: "Mar – Oct",
    safetyScore: 93,
  },
  {
    slug: "goa",
    name: "Goa",
    country: "India",
    image:
      "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1587922546307-776227941871?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 12999,
    duration: "4D/3N",
    rating: 4.6,
    reviews: 934,
    tag: "Weekend Favourite",
    description:
      "Beach shacks, Portuguese quarters, and sunset cruises on India's favourite coastline.",
    highlights: ["Baga-Calangute beach hop", "Old Goa churches", "Sunset river cruise"],
    bestTime: "Nov – Feb",
    safetyScore: 92,
  },
  {
    slug: "kerala",
    name: "Kerala",
    country: "India",
    image:
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1602313888344-a3e447dbd6de?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 18999,
    duration: "5D/4N",
    rating: 4.8,
    reviews: 447,
    tag: "God's Own Country",
    description:
      "Backwater houseboats, tea-garden hill stations, and Ayurvedic wellness retreats.",
    highlights: ["Alleppey houseboat", "Munnar tea gardens", "Ayurvedic spa"],
    bestTime: "Sep – Mar",
    safetyScore: 95,
  },
  {
    slug: "andaman",
    name: "Andaman",
    country: "India",
    image:
      "https://images.unsplash.com/photo-1589979481223-deb893043163?q=80&w=1600&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1589979481223-deb893043163?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=1600&auto=format&fit=crop",
    ],
    startingPrice: 27999,
    duration: "5D/4N",
    rating: 4.7,
    reviews: 262,
    tag: "Island Escape",
    description:
      "Coral reefs, powder-white beaches, and glass-bottom boat rides across the islands.",
    highlights: ["Radhanagar Beach", "Scuba at Havelock", "Cellular Jail light show"],
    bestTime: "Oct – May",
    safetyScore: 94,
  },
];

export const packages: TourPackage[] = [
  {
    slug: "bangkok-pattaya-explorer",
    title: "Bangkok & Pattaya Explorer",
    destinationSlug: "thailand",
    image:
      "https://images.unsplash.com/photo-1508009603885-50cf7c579365?q=80&w=1600&auto=format&fit=crop",
    price: 34999,
    originalPrice: 44999,
    discountPercent: 22,
    duration: "6 Days / 5 Nights",
    nights: 5,
    days: 6,
    inclusions: ["Flights", "4-Star Hotels", "Daily Breakfast", "Island Cruise", "Airport Transfers"],
    category: "Group",
    rating: 4.7,
    reviews: 356,
    overview:
      "A well-paced Thailand circuit covering Bangkok's temples and markets before winding down on Pattaya's beaches.",
    itinerary: [
      { day: 1, title: "Arrive Bangkok", description: "Airport pickup and evening at leisure near Sukhumvit." },
      { day: 2, title: "Bangkok City Tour", description: "Grand Palace, Wat Arun, and a river dinner cruise." },
      { day: 3, title: "Transfer to Pattaya", description: "Scenic drive and evening at Pattaya Walking Street." },
      { day: 4, title: "Coral Island Cruise", description: "Speedboat to Coral Island with water sports and lunch." },
      { day: 5, title: "Leisure & Shopping", description: "Optional Nong Nooch Garden visit and shopping time." },
      { day: 6, title: "Departure", description: "Transfer to airport for your flight home." },
    ],
  },
  {
    slug: "bali-honeymoon-bliss",
    title: "Bali Honeymoon Bliss",
    destinationSlug: "bali",
    image:
      "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=1600&auto=format&fit=crop",
    price: 38999,
    originalPrice: 47999,
    discountPercent: 18,
    duration: "5 Days / 4 Nights",
    nights: 4,
    days: 5,
    inclusions: ["Flights", "Private Pool Villa", "Candlelight Dinner", "Airport Transfers"],
    category: "Honeymoon",
    rating: 4.9,
    reviews: 289,
    overview:
      "A romantic Bali escape built around private-pool villas, cliffside sunsets, and a candlelight dinner.",
    itinerary: [
      { day: 1, title: "Arrive Ubud", description: "Check-in to your private villa and relax by the pool." },
      { day: 2, title: "Ubud Highlights", description: "Rice terraces, monkey forest, and a spa evening." },
      { day: 3, title: "Transfer to Seminyak", description: "Beach-club afternoon and candlelight dinner on the sand." },
      { day: 4, title: "Uluwatu Sunset", description: "Cliff temple visit and traditional Kecak fire dance." },
      { day: 5, title: "Departure", description: "Leisure morning before airport transfer." },
    ],
  },
  {
    slug: "dubai-luxury-escape",
    title: "Dubai Luxury Escape",
    destinationSlug: "dubai",
    image:
      "https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=1600&auto=format&fit=crop",
    price: 42999,
    originalPrice: 52999,
    discountPercent: 19,
    duration: "5 Days / 4 Nights",
    nights: 4,
    days: 5,
    inclusions: ["Flights", "5-Star Hotel", "Desert Safari", "Burj Khalifa Tickets"],
    category: "Luxury",
    rating: 4.8,
    reviews: 412,
    overview:
      "Dubai's headline experiences bundled into one smooth five-star itinerary.",
    itinerary: [
      { day: 1, title: "Arrive Dubai", description: "Check-in and evening at Dubai Marina." },
      { day: 2, title: "City Tour", description: "Burj Khalifa At The Top and Dubai Mall fountains." },
      { day: 3, title: "Desert Safari", description: "Dune bashing, camel rides, and BBQ dinner under the stars." },
      { day: 4, title: "Leisure Day", description: "Optional Palm Jumeirah or Global Village visit." },
      { day: 5, title: "Departure", description: "Transfer to airport for your flight." },
    ],
  },
  {
    slug: "maldives-overwater-romance",
    title: "Maldives Overwater Romance",
    destinationSlug: "maldives",
    image:
      "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?q=80&w=1600&auto=format&fit=crop",
    price: 64999,
    originalPrice: 79999,
    discountPercent: 19,
    duration: "4 Days / 3 Nights",
    nights: 3,
    days: 4,
    inclusions: ["Seaplane Transfer", "Overwater Villa", "All Meals", "Sandbank Dinner"],
    category: "Honeymoon",
    rating: 4.9,
    reviews: 198,
    overview:
      "Three nights suspended over turquoise water, capped with a private sandbank dinner.",
    itinerary: [
      { day: 1, title: "Arrive & Seaplane Transfer", description: "Scenic seaplane ride to your overwater villa." },
      { day: 2, title: "Reef & Relax", description: "Snorkeling excursion and spa afternoon." },
      { day: 3, title: "Sandbank Dinner", description: "Private dinner on a secluded sandbank at sunset." },
      { day: 4, title: "Departure", description: "Seaplane transfer back for your flight home." },
    ],
  },
  {
    slug: "europe-grand-circuit",
    title: "Europe Grand Circuit",
    destinationSlug: "europe",
    image:
      "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=1600&auto=format&fit=crop",
    price: 129999,
    originalPrice: 154999,
    discountPercent: 16,
    duration: "10 Days / 9 Nights",
    nights: 9,
    days: 10,
    inclusions: ["Flights", "4-Star Hotels", "Eurail Pass", "Daily Breakfast", "City Tours"],
    category: "Luxury",
    rating: 4.9,
    reviews: 176,
    overview:
      "Paris, Switzerland, and Italy woven into one grand, comfortably-paced rail journey.",
    itinerary: [
      { day: 1, title: "Arrive Paris", description: "Check-in near the Champs-Élysées." },
      { day: 2, title: "Paris City Tour", description: "Eiffel Tower, Louvre, and a Seine dinner cruise." },
      { day: 3, title: "Rail to Switzerland", description: "Scenic train transfer to Lucerne." },
      { day: 4, title: "Swiss Alps", description: "Mount Titlis cable car and alpine village visit." },
      { day: 5, title: "Rail to Italy", description: "Transfer to Milan then onward to Venice." },
      { day: 6, title: "Venice", description: "Gondola ride through the canals." },
      { day: 7, title: "Florence", description: "Renaissance art and architecture walking tour." },
      { day: 8, title: "Rome", description: "Colosseum and Vatican City tour." },
      { day: 9, title: "Leisure in Rome", description: "Free day for shopping or optional excursions." },
      { day: 10, title: "Departure", description: "Transfer to airport for your flight home." },
    ],
  },
  {
    slug: "vietnam-heritage-trail",
    title: "Vietnam Heritage Trail",
    destinationSlug: "vietnam",
    image:
      "https://images.unsplash.com/photo-1509923074449-1bf42303a279?q=80&w=1600&auto=format&fit=crop",
    price: 32999,
    originalPrice: 39999,
    discountPercent: 17,
    duration: "6 Days / 5 Nights",
    nights: 5,
    days: 6,
    inclusions: ["Flights", "Ha Long Bay Cruise", "4-Star Hotels", "Daily Breakfast"],
    category: "Family",
    rating: 4.7,
    reviews: 154,
    overview:
      "An overnight Ha Long Bay cruise bookended by the heritage streets of Hanoi and Hoi An.",
    itinerary: [
      { day: 1, title: "Arrive Hanoi", description: "Old Quarter walking tour in the evening." },
      { day: 2, title: "Ha Long Bay Cruise", description: "Overnight cruise with kayaking and cave visits." },
      { day: 3, title: "Return to Hanoi", description: "Fly to Da Nang and transfer to Hoi An." },
      { day: 4, title: "Hoi An Ancient Town", description: "Lantern-lit old town and tailor shopping." },
      { day: 5, title: "Ba Na Hills", description: "Golden Bridge and French village cable car." },
      { day: 6, title: "Departure", description: "Transfer to airport for your flight home." },
    ],
  },
  {
    slug: "kashmir-valley-of-dreams",
    title: "Kashmir Valley of Dreams",
    destinationSlug: "kashmir",
    image:
      "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=1600&auto=format&fit=crop",
    price: 21999,
    originalPrice: 26999,
    discountPercent: 18,
    duration: "6 Days / 5 Nights",
    nights: 5,
    days: 6,
    inclusions: ["Houseboat Stay", "Private Cab", "Daily Breakfast & Dinner", "Gondola Ride"],
    category: "Family",
    rating: 4.8,
    reviews: 231,
    overview:
      "Srinagar's houseboats, Gulmarg's gondola, and Pahalgam's meadows in one gentle circuit.",
    itinerary: [
      { day: 1, title: "Arrive Srinagar", description: "Check-in to a houseboat on Dal Lake." },
      { day: 2, title: "Srinagar Sightseeing", description: "Mughal gardens and a shikara ride." },
      { day: 3, title: "Gulmarg Day Trip", description: "Gondola ride up Apharwat Peak." },
      { day: 4, title: "Pahalgam", description: "Betaab Valley and Lidder River views." },
      { day: 5, title: "Leisure in Pahalgam", description: "Optional pony rides and valley walks." },
      { day: 6, title: "Departure", description: "Transfer to Srinagar airport." },
    ],
  },
  {
    slug: "goa-weekend-getaway",
    title: "Goa Weekend Getaway",
    destinationSlug: "goa",
    image:
      "https://images.unsplash.com/photo-1587922546307-776227941871?q=80&w=1600&auto=format&fit=crop",
    price: 12999,
    originalPrice: 16999,
    discountPercent: 23,
    duration: "4 Days / 3 Nights",
    nights: 3,
    days: 4,
    inclusions: ["Beach Resort", "Airport Transfers", "Sunset Cruise", "Daily Breakfast"],
    category: "Weekend",
    rating: 4.6,
    reviews: 402,
    overview: "A quick beach reset covering Goa's best shacks, churches, and sunset cruises.",
    itinerary: [
      { day: 1, title: "Arrive Goa", description: "Check-in and relax at Calangute Beach." },
      { day: 2, title: "North Goa Tour", description: "Fort Aguada, Baga, and Anjuna flea market." },
      { day: 3, title: "South Goa & Cruise", description: "Old Goa churches and evening river cruise." },
      { day: 4, title: "Departure", description: "Transfer to Goa airport." },
    ],
  },
];

export const testimonials: Testimonial[] = [
  {
    name: "Ananya Rao",
    location: "Bengaluru",
    image:
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=300&auto=format&fit=crop",
    rating: 5,
    review:
      "Every detail was handled — from visa paperwork to the exact hotel we asked for. Our Maldives trip felt completely worry-free.",
    trip: "Maldives Overwater Romance",
  },
  {
    name: "Rohan Malhotra",
    location: "Delhi",
    image:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&auto=format&fit=crop",
    rating: 5,
    review:
      "The Europe circuit was paced perfectly. Our coordinator was reachable 24x7 and rerouted us around a train delay without any stress.",
    trip: "Europe Grand Circuit",
  },
  {
    name: "Priya & Karthik",
    location: "Chennai",
    image:
      "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?q=80&w=300&auto=format&fit=crop",
    rating: 5,
    review:
      "Booked our honeymoon three weeks before the wedding. Travel Safe matched us to a villa within budget and it still felt five-star.",
    trip: "Bali Honeymoon Bliss",
  },
  {
    name: "Fatima Sheikh",
    location: "Hyderabad",
    image:
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=300&auto=format&fit=crop",
    rating: 4,
    review:
      "Great value on the Kashmir package — houseboat, drivers, and hotels were all exactly as promised, no hidden costs.",
    trip: "Kashmir Valley of Dreams",
  },
];

export const travelCategories = [
  {
    name: "Family Tours",
    slug: "family",
    description: "Easy pacing, connecting rooms, and kid-friendly stops.",
    image:
      "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Honeymoon",
    slug: "honeymoon",
    description: "Private villas, candlelight dinners, and quiet sunsets.",
    image:
      "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Adventure",
    slug: "adventure",
    description: "Treks, dives, and adrenaline-first itineraries.",
    image:
      "https://images.unsplash.com/photo-1551632811-561732d1e306?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Luxury",
    slug: "luxury",
    description: "Five-star stays and private guided experiences.",
    image:
      "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Group Trips",
    slug: "group",
    description: "Friend circles and college gangs, sorted end to end.",
    image:
      "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Corporate Travel",
    slug: "corporate",
    description: "Offsites, incentive trips, and MICE logistics.",
    image:
      "https://images.unsplash.com/photo-1497366811353-6870744d04b2?q=80&w=1200&auto=format&fit=crop",
  },
  {
    name: "Weekend Getaways",
    slug: "weekend",
    description: "Short-haul resets you can book with a week's notice.",
    image:
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop",
  },
];

export const galleryImages = [
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1519046904884-53103b34b206?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1508009603885-50cf7c579365?q=80&w=900&auto=format&fit=crop",
];

export const stats: StatItem[] = [
  { label: "Happy Travellers", value: 15000, suffix: "+" },
  { label: "Curated Packages", value: 500, suffix: "+" },
  { label: "Destinations Covered", value: 100, suffix: "+" },
  { label: "Average Rating", value: 4.9, suffix: "/5" },
];

export const blogPosts: BlogPost[] = [
  {
    slug: "first-time-international-trip-checklist",
    title: "The First-Time International Traveller's Checklist",
    excerpt:
      "Passports, visas, insurance, and packing — everything to sort before your first trip abroad.",
    image:
      "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=1200&auto=format&fit=crop",
    author: "Meera Nair",
    date: "2026-06-12",
    readTime: "6 min read",
    category: "Travel Tips",
    content:
      "Planning your first trip abroad can feel overwhelming, but a simple checklist takes most of the stress out of it. Start with your passport — check the expiry date is at least six months out from your return date. Next, confirm visa requirements for your destination; Travel Safe's visa desk can tell you exactly what documents you need and how long processing takes. Pack a printed copy of your itinerary, hotel bookings, and travel insurance alongside digital copies saved to your phone. Finally, notify your bank of your travel dates so your cards aren't blocked abroad, and carry a small amount of local currency for your first day.",
  },
  {
    slug: "best-time-to-visit-bali",
    title: "Best Time to Visit Bali: A Season-by-Season Guide",
    excerpt:
      "Dry season crowds, shoulder-season deals, or green-season rains — here's how to pick your window.",
    image:
      "https://images.unsplash.com/photo-1544644181-1484b3fdfc62?q=80&w=1200&auto=format&fit=crop",
    author: "Aditya Kulkarni",
    date: "2026-05-28",
    readTime: "5 min read",
    category: "Destination Guide",
    content:
      "Bali's dry season, running from April to October, brings the clearest skies and calmest seas, making it ideal for beach days and boat trips to the Gili Islands. This is also the busiest and most expensive stretch, particularly around July and August. The shoulder months of April, May, June, and September offer a good balance of good weather and thinner crowds. The wet season from November to March brings short, heavy afternoon showers but lush green rice terraces and noticeably lower hotel rates, which suits travellers who don't mind planning around brief downpours.",
  },
  {
    slug: "visa-on-arrival-countries-for-indians",
    title: "10 Visa-on-Arrival Countries Perfect for a Quick Getaway",
    excerpt:
      "No lengthy paperwork required — these destinations let Indian passport holders land and go.",
    image:
      "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=1200&auto=format&fit=crop",
    author: "Sana Iyer",
    date: "2026-04-15",
    readTime: "7 min read",
    category: "Visa Guide",
    content:
      "If you're short on planning time, visa-on-arrival destinations are the easiest way to book a trip without weeks of paperwork. Thailand, Indonesia, and the Maldives all offer visa-on-arrival for Indian passport holders, typically requiring just a return ticket, hotel booking, and proof of funds. Vietnam and Cambodia allow e-visa applications that process within a few working days. Always double-check the latest requirements before you fly, since rules can change with little notice — our visa desk keeps an updated list for every route we sell.",
  },
  {
    slug: "how-to-pack-light-for-a-two-week-trip",
    title: "How to Pack Light for a Two-Week Multi-City Trip",
    excerpt:
      "One carry-on, two weeks, zero regrets — our packing framework for long multi-stop itineraries.",
    image:
      "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?q=80&w=1200&auto=format&fit=crop",
    author: "Meera Nair",
    date: "2026-03-02",
    readTime: "4 min read",
    category: "Travel Tips",
    content:
      "Packing for a long multi-city trip comes down to building a small capsule wardrobe rather than packing for every possible day. Choose three or four base colours and pack tops and bottoms that all mix and match, along with one layer for cooler evenings. Roll clothes instead of folding to save space, and use packing cubes to keep categories separate so you're not unpacking your entire bag to find one item. Leave a fifth of your bag empty for souvenirs, and always carry one full outfit plus essential medication in your cabin bag in case checked luggage is delayed.",
  },
];
