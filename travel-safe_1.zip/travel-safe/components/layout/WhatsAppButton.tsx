"use client";

import { motion } from "framer-motion";

export function WhatsAppButton() {
  return (
    <motion.a
      href="https://wa.me/911234567890?text=Hi%20Travel%20Safe%2C%20I%27d%20like%20to%20plan%20a%20trip."
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 200, damping: 15 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 left-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg"
    >
      <span className="absolute inline-flex h-full w-full animate-ping-slow rounded-full bg-[#25D366]" />
      <svg
        viewBox="0 0 32 32"
        className="relative h-7 w-7 fill-white"
        aria-hidden="true"
      >
        <path d="M16.001 3C9.372 3 4 8.373 4 15.001c0 2.386.638 4.62 1.752 6.549L4 29l7.633-1.712A11.94 11.94 0 0 0 16.001 27C22.63 27 28 21.628 28 15.001 28 8.373 22.63 3 16.001 3Zm0 21.7c-1.94 0-3.75-.52-5.31-1.42l-.38-.22-4.53 1.017 1.05-4.41-.25-.4a9.63 9.63 0 0 1-1.48-5.264C5.1 9.51 10.11 4.5 16.001 4.5 21.892 4.5 26.9 9.51 26.9 15.001c0 5.892-5.008 9.699-10.899 9.699Zm5.55-7.362c-.303-.152-1.792-.884-2.07-.985-.278-.101-.48-.152-.682.152-.202.303-.783.985-.96 1.187-.177.202-.354.227-.657.076-.303-.152-1.279-.472-2.436-1.505-.9-.803-1.508-1.795-1.685-2.098-.177-.303-.019-.467.133-.618.136-.136.303-.354.454-.53.152-.177.202-.303.303-.505.101-.202.05-.379-.025-.53-.076-.152-.682-1.645-.935-2.253-.246-.591-.497-.511-.682-.52l-.581-.01c-.202 0-.53.076-.808.379-.278.303-1.06 1.036-1.06 2.528 0 1.492 1.086 2.933 1.237 3.135.152.202 2.138 3.263 5.181 4.576.724.313 1.288.5 1.728.64.726.231 1.386.198 1.908.12.582-.087 1.792-.733 2.045-1.44.253-.708.253-1.315.177-1.44-.076-.126-.278-.202-.581-.354Z" />
      </svg>
    </motion.a>
  );
}
