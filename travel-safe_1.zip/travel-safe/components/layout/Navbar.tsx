"use client";

import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, Phone, ShieldCheck, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ThemeToggle } from "./ThemeToggle";

const navLinks = [
  { label: "Home", href: "/" },
  { label: "International", href: "/destinations?type=international" },
  { label: "Domestic", href: "/destinations?type=domestic" },
  { label: "Honeymoon", href: "/destinations?category=honeymoon" },
  { label: "Group Tours", href: "/destinations?category=group" },
  { label: "Corporate", href: "/destinations?category=corporate" },
  { label: "Visa Services", href: "/contact#visa" },
  { label: "Blogs", href: "/blog" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const isHome = pathname === "/";
  const solid = scrolled || !isHome;

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        solid
          ? "glass shadow-sm"
          : "bg-gradient-to-b from-primary-950/70 via-primary-950/20 to-transparent"
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 sm:px-8">
        <Link href="/" className="flex items-center gap-2">
          <span
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-full",
              solid ? "bg-primary" : "bg-white/15 backdrop-blur-sm"
            )}
          >
            <ShieldCheck size={18} className={solid ? "text-white" : "text-white"} />
          </span>
          <span
            className={cn(
              "text-lg font-bold tracking-tight",
              solid ? "text-primary-900 dark:text-white" : "text-white"
            )}
          >
            Travel Safe
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className={cn(
                "rounded-full px-3 py-2 text-[13px] font-medium transition-colors",
                solid
                  ? "text-primary-900/80 hover:bg-primary-50 hover:text-primary dark:text-white/80 dark:hover:bg-white/10"
                  : "text-white/85 hover:bg-white/10 hover:text-white"
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href="tel:+911234567890"
            className={cn(
              "flex items-center gap-1.5 text-xs font-semibold",
              solid ? "text-primary-800 dark:text-white" : "text-white"
            )}
          >
            <Phone size={14} />
            +91 123 456 7890
          </a>
          <ThemeToggle />
          <Button href="/contact" size="sm" variant={solid ? "primary" : "outline"}>
            Plan My Trip
          </Button>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <ThemeToggle
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-full",
              solid ? "text-primary-900 dark:text-white" : "text-white"
            )}
          />
          <button
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-full",
              solid ? "text-primary-900 dark:text-white" : "text-white"
            )}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden bg-white lg:hidden dark:bg-primary-950"
          >
            <nav className="flex flex-col gap-1 px-5 pb-6">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="rounded-xl px-3 py-3 text-sm font-medium text-primary-900 hover:bg-primary-50 dark:text-white dark:hover:bg-white/10"
                >
                  {link.label}
                </Link>
              ))}
              <Button href="/contact" size="sm" className="mt-2 justify-center">
                Plan My Trip
              </Button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
