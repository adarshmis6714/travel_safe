"use client";

import { motion } from "framer-motion";
import { Phone } from "lucide-react";

export function CallButton() {
  return (
    <motion.a
      href="tel:+911234567890"
      aria-label="Call Travel Safe"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1.15, type: "spring", stiffness: 200, damping: 15 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-white shadow-lg"
    >
      <Phone size={22} className="fill-white" />
    </motion.a>
  );
}
