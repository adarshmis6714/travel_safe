import { Container } from "@/components/ui/Container";
import {
  Facebook,
  Instagram,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Twitter,
  Youtube,
} from "lucide-react";
import Link from "next/link";

const quickLinks = [
  { label: "International Tours", href: "/destinations?type=international" },
  { label: "Domestic Tours", href: "/destinations?type=domestic" },
  { label: "Honeymoon Packages", href: "/destinations?category=honeymoon" },
  { label: "Group Tours", href: "/destinations?category=group" },
  { label: "Corporate Tours", href: "/destinations?category=corporate" },
  { label: "Visa Services", href: "/contact#visa" },
];

const company = [
  { label: "About Us", href: "/about" },
  { label: "Blogs", href: "/blog" },
  { label: "Contact", href: "/contact" },
  { label: "Careers", href: "/about#careers" },
];

const legal = [
  { label: "Privacy Policy", href: "/privacy-policy" },
  { label: "Terms & Conditions", href: "/terms-conditions" },
  { label: "Refund Policy", href: "/refund-policy" },
];

const socials = [
  { icon: Instagram, href: "https://instagram.com", label: "Instagram" },
  { icon: Facebook, href: "https://facebook.com", label: "Facebook" },
  { icon: Twitter, href: "https://twitter.com", label: "Twitter" },
  { icon: Youtube, href: "https://youtube.com", label: "YouTube" },
  { icon: Linkedin, href: "https://linkedin.com", label: "LinkedIn" },
];

export function Footer() {
  return (
    <footer className="bg-primary-950 text-white/70">
      <Container className="grid grid-cols-1 gap-12 py-16 sm:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <Link href="/" className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary">
              <ShieldCheck size={18} className="text-primary-950" />
            </span>
            <span className="text-lg font-bold text-white">Travel Safe</span>
          </Link>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/60">
            Explore the world with confidence. Travel Safe designs handpicked
            itineraries backed by verified stays, transparent pricing, and a
            24x7 support team that travels with you in spirit, if not in person.
          </p>
          <div className="mt-6 flex gap-3">
            {socials.map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 transition-colors hover:bg-secondary hover:text-primary-950"
              >
                <Icon size={15} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-wide text-white">
            Explore
          </h4>
          <ul className="mt-4 space-y-3 text-sm">
            {quickLinks.map((l) => (
              <li key={l.label}>
                <Link href={l.href} className="transition-colors hover:text-secondary">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-wide text-white">
            Company
          </h4>
          <ul className="mt-4 space-y-3 text-sm">
            {company.map((l) => (
              <li key={l.label}>
                <Link href={l.href} className="transition-colors hover:text-secondary">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <h4 className="mt-6 text-sm font-bold uppercase tracking-wide text-white">
            Legal
          </h4>
          <ul className="mt-4 space-y-3 text-sm">
            {legal.map((l) => (
              <li key={l.label}>
                <Link href={l.href} className="transition-colors hover:text-secondary">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-bold uppercase tracking-wide text-white">
            Contact
          </h4>
          <ul className="mt-4 space-y-4 text-sm">
            <li className="flex items-start gap-3">
              <MapPin size={16} className="mt-0.5 flex-shrink-0 text-secondary" />
              <span>4th Floor, Skyline Towers, MG Road, Bengaluru, India</span>
            </li>
            <li className="flex items-center gap-3">
              <Phone size={16} className="flex-shrink-0 text-secondary" />
              <a href="tel:+911234567890" className="hover:text-secondary">
                +91 123 456 7890
              </a>
            </li>
            <li className="flex items-center gap-3">
              <Mail size={16} className="flex-shrink-0 text-secondary" />
              <a href="mailto:hello@travelsafe.com" className="hover:text-secondary">
                hello@travelsafe.com
              </a>
            </li>
          </ul>
        </div>
      </Container>

      <div className="border-t border-white/10">
        <Container className="flex flex-col items-center justify-between gap-3 py-6 text-xs text-white/50 sm:flex-row">
          <p>&copy; {new Date().getFullYear()} Travel Safe Holidays Pvt. Ltd. All rights reserved.</p>
          <p>IATA &amp; DGCA registered travel partner</p>
        </Container>
      </div>
    </footer>
  );
}
