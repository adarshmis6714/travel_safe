import { ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

export function SafetyBadge({
  score,
  className,
}: {
  score: number;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-1.5 rounded-full bg-white/90 px-2.5 py-1 text-primary-800 shadow-sm backdrop-blur-sm dark:bg-ink/80 dark:text-white",
        className
      )}
      title={`Travel Safe Score: ${score}/100`}
    >
      <ShieldCheck size={13} className="text-secondary-600 dark:text-secondary-300" strokeWidth={2.5} />
      <span className="text-[11px] font-bold tabular-nums">{score}</span>
    </div>
  );
}
