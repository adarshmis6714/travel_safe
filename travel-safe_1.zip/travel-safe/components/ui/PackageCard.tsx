"use client";

import { TourPackage } from "@/lib/types";
import { formatINR } from "@/lib/utils";
import { motion } from "framer-motion";
import { BadgeCheck, CalendarDays, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export function PackageCard({
  pkg,
  index = 0,
}: {
  pkg: TourPackage;
  index?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 28 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: (index % 4) * 0.08, ease: "easeOut" }}
      className="group grid w-full flex-shrink-0 grid-cols-1 overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-black/5 transition-all duration-500 hover:shadow-card-hover sm:grid-cols-5 dark:bg-primary-950 dark:ring-white/10"
    >
      <div className="relative col-span-2 h-52 sm:h-full">
        <Image
          src={pkg.image}
          alt={pkg.title}
          fill
          sizes="(max-width: 768px) 90vw, 320px"
          className="object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {pkg.discountPercent && (
          <span className="absolute left-3 top-3 rounded-full bg-primary px-3 py-1 text-[11px] font-bold text-white shadow-sm">
            {pkg.discountPercent}% OFF
          </span>
        )}
      </div>

      <div className="col-span-3 flex flex-col justify-between gap-4 p-5 sm:p-6">
        <div>
          <div className="flex items-start justify-between gap-3">
            <h3 className="text-lg font-bold leading-snug text-primary-900 dark:text-white">
              {pkg.title}
            </h3>
            <div className="flex flex-shrink-0 items-center gap-1 text-sm font-semibold text-primary-900 dark:text-white">
              <Star size={14} className="fill-accent text-accent" />
              {pkg.rating}
            </div>
          </div>
          <p className="mt-1 flex items-center gap-1.5 text-xs text-primary-900/50 dark:text-white/50">
            <CalendarDays size={13} />
            {pkg.duration}
          </p>

          <ul className="mt-3 flex flex-wrap gap-2">
            {pkg.inclusions.slice(0, 3).map((item) => (
              <li
                key={item}
                className="flex items-center gap-1 rounded-full bg-secondary-50 px-2.5 py-1 text-[11px] font-medium text-secondary-700 dark:bg-white/10 dark:text-secondary-200"
              >
                <BadgeCheck size={12} />
                {item}
              </li>
            ))}
            {pkg.inclusions.length > 3 && (
              <li className="flex items-center rounded-full bg-primary-50 px-2.5 py-1 text-[11px] font-medium text-primary-700 dark:bg-white/10 dark:text-white/70">
                +{pkg.inclusions.length - 3} more
              </li>
            )}
          </ul>
        </div>

        <div className="flex items-end justify-between border-t border-primary-900/5 pt-4 dark:border-white/10">
          <div>
            {pkg.originalPrice && (
              <p className="text-xs text-primary-900/40 line-through dark:text-white/40">
                {formatINR(pkg.originalPrice)}
              </p>
            )}
            <p className="text-xl font-bold text-primary-800 dark:text-white">
              {formatINR(pkg.price)}
              <span className="ml-1 text-xs font-medium text-primary-900/50 dark:text-white/50">
                / person
              </span>
            </p>
          </div>
          <Link
            href={`/packages/${pkg.slug}`}
            className="rounded-full bg-accent px-5 py-2.5 text-xs font-bold text-primary-900 shadow-sm transition-colors hover:bg-accent-300"
          >
            Book Now
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
