import { Container } from "@/components/ui/Container";
import type { ReactNode } from "react";

export function LegalPage({
  title,
  updated,
  children,
}: {
  title: string;
  updated: string;
  children: ReactNode;
}) {
  return (
    <div className="pb-24 pt-32">
      <Container className="max-w-3xl">
        <h1 className="text-3xl font-bold text-primary-900 dark:text-white">{title}</h1>
        <p className="mt-2 text-xs text-primary-900/50 dark:text-white/50">
          Last updated: {updated}
        </p>
        <div className="prose prose-sm mt-8 max-w-none space-y-6 text-primary-900/75 dark:text-white/75 [&_h2]:text-lg [&_h2]:font-bold [&_h2]:text-primary-900 dark:[&_h2]:text-white [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:pl-5 [&_li]:leading-relaxed">
          {children}
        </div>
      </Container>
    </div>
  );
}
