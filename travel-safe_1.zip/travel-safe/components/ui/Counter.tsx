"use client";

import { useEffect, useRef, useState } from "react";
import { useInView, useMotionValue, useSpring } from "framer-motion";

export function Counter({
  value,
  suffix = "",
  duration = 1.6,
}: {
  value: number;
  suffix?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });
  const motionValue = useMotionValue(0);
  const springValue = useSpring(motionValue, {
    duration: duration * 1000,
    bounce: 0,
  });
  const [displayValue, setDisplayValue] = useState("0");

  useEffect(() => {
    if (isInView) {
      motionValue.set(value);
    }
  }, [isInView, motionValue, value]);

  useEffect(() => {
    const unsubscribe = springValue.on("change", (latest) => {
      const isDecimal = value % 1 !== 0;
      setDisplayValue(
        isDecimal ? latest.toFixed(1) : Math.floor(latest).toLocaleString("en-IN")
      );
    });
    return unsubscribe;
  }, [springValue, value]);

  return (
    <span ref={ref} className="tabular-nums font-mono">
      {displayValue}
      {suffix}
    </span>
  );
}
