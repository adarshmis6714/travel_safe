import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export function Badge({
  children,
  className,
  tone = "primary",
}: {
  children: ReactNode;
  className?: string;
  tone?: "primary" | "secondary" | "accent" | "white";
}) {
  const tones = {
    primary: "bg-primary-50 text-primary-700 dark:bg-primary-900/40 dark:text-primary-100",
    secondary: "bg-secondary-50 text-secondary-700 dark:bg-secondary-900/40 dark:text-secondary-100",
    accent: "bg-accent-50 text-accent-700 dark:bg-accent-900/40 dark:text-accent-200",
    white: "bg-white/90 text-primary-700",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wider",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}
