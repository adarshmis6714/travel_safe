"use client";

import { Destination } from "@/lib/types";
import { formatINR } from "@/lib/utils";
import { motion } from "framer-motion";
import { Clock, Star } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { SafetyBadge } from "./SafetyBadge";

export function DestinationCard({
  destination,
  index = 0,
}: {
  destination: Destination;
  index?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, delay: (index % 5) * 0.08, ease: "easeOut" }}
      className="group relative flex w-full flex-shrink-0 flex-col overflow-hidden rounded-3xl bg-white shadow-card ring-1 ring-black/5 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-card-hover dark:bg-primary-950 dark:ring-white/10"
    >
      <div className="relative h-56 w-full overflow-hidden">
        <Image
          src={destination.image}
          alt={`${destination.name}, ${destination.country}`}
          fill
          sizes="(max-width: 768px) 90vw, (max-width: 1200px) 33vw, 25vw"
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary-950/70 via-transparent to-transparent" />
        {destination.tag && (
          <span className="absolute left-4 top-4 rounded-full bg-accent px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-primary-900 shadow-sm">
            {destination.tag}
          </span>
        )}
        <SafetyBadge score={destination.safetyScore} className="absolute right-4 top-4" />
        <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between text-white">
          <div>
            <h3 className="text-xl font-bold leading-tight">{destination.name}</h3>
            <p className="text-xs text-white/75">{destination.country}</p>
          </div>
          <div className="flex items-center gap-1 rounded-full bg-white/15 px-2 py-1 backdrop-blur-sm">
            <Star size={12} className="fill-accent text-accent" />
            <span className="text-xs font-semibold">{destination.rating}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div className="flex items-center justify-between text-sm text-primary-900/60 dark:text-white/60">
          <span className="flex items-center gap-1.5">
            <Clock size={14} />
            {destination.duration}
          </span>
          <span>{destination.reviews} reviews</span>
        </div>
        <div className="flex items-center justify-between border-t border-primary-900/5 pt-4 dark:border-white/10">
          <div>
            <p className="text-[11px] uppercase tracking-wide text-primary-900/50 dark:text-white/50">
              Starting from
            </p>
            <p className="text-lg font-bold text-primary-800 dark:text-white">
              {formatINR(destination.startingPrice)}
            </p>
          </div>
          <Link
            href={`/destinations/${destination.slug}`}
            className="rounded-full bg-primary-50 px-4 py-2 text-xs font-bold text-primary-700 transition-colors hover:bg-primary hover:text-white dark:bg-white/10 dark:text-white"
          >
            Explore
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
