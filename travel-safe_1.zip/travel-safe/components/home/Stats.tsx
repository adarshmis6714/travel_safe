import { Container } from "@/components/ui/Container";
import { Counter } from "@/components/ui/Counter";
import { stats } from "@/lib/data";

export function Stats() {
  return (
    <section className="border-y border-primary-900/5 bg-white py-16 dark:border-white/10 dark:bg-ink">
      <Container>
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <p className="text-3xl font-bold text-primary-800 sm:text-4xl dark:text-white">
                <Counter value={s.value} suffix={s.suffix} />
              </p>
              <p className="mt-2 text-xs font-medium uppercase tracking-wide text-primary-900/50 sm:text-sm dark:text-white/50">
                {s.label}
              </p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
