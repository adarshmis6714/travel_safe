"use client";

import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { destinations } from "@/lib/data";
import { motion } from "framer-motion";
import { CheckCircle2, Send } from "lucide-react";
import { useState } from "react";

const budgets = ["Under ₹25,000", "₹25,000 – ₹50,000", "₹50,000 – ₹1,00,000", "₹1,00,000+"];

export function EnquirySection() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    // Hook this up to your enquiry API route / CRM webhook.
    setSubmitted(true);
  }

  return (
    <section className="bg-white py-24 dark:bg-ink" id="enquiry">
      <Container className="grid grid-cols-1 gap-12 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <SectionHeading
            eyebrow="Get a Custom Quote"
            title="Tell us your dream trip. We'll do the rest."
            description="Share a few details and a destination specialist will call you within one business hour with a tailored itinerary and quote."
          />
          <ul className="mt-8 space-y-3">
            {["No obligation, free consultation", "Response within 60 minutes", "100% transparent, all-inclusive pricing"].map(
              (item) => (
                <li key={item} className="flex items-center gap-2.5 text-sm text-primary-900/70 dark:text-white/70">
                  <CheckCircle2 size={16} className="text-secondary-600 dark:text-secondary-300" />
                  {item}
                </li>
              )
            )}
          </ul>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6 }}
          className="rounded-3xl border border-primary-900/5 bg-primary-50/50 p-6 shadow-card sm:p-8 lg:col-span-3 dark:border-white/10 dark:bg-primary-950"
        >
          {submitted ? (
            <div className="flex h-full min-h-[320px] flex-col items-center justify-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-secondary-50 text-secondary-600 dark:bg-white/10 dark:text-secondary-300">
                <CheckCircle2 size={28} />
              </span>
              <h3 className="mt-4 text-lg font-bold text-primary-900 dark:text-white">
                Thanks! Your enquiry is in.
              </h3>
              <p className="mt-2 max-w-xs text-sm text-primary-900/60 dark:text-white/60">
                A Travel Safe specialist will reach out to you shortly with a custom itinerary.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Full Name" name="name" placeholder="Aditi Sharma" required />
              <Field label="Phone Number" name="phone" type="tel" placeholder="+91 98765 43210" required />
              <Field label="Email Address" name="email" type="email" placeholder="you@example.com" required className="sm:col-span-2" />

              <label className="flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70">
                Preferred Destination
                <select
                  name="destination"
                  required
                  defaultValue=""
                  className="rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white"
                >
                  <option value="" disabled>
                    Select a destination
                  </option>
                  {destinations.map((d) => (
                    <option key={d.slug} value={d.name}>
                      {d.name}
                    </option>
                  ))}
                  <option value="Other">Somewhere else</option>
                </select>
              </label>

              <Field label="Travel Date" name="date" type="date" />

              <label className="flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70">
                Budget (per person)
                <select
                  name="budget"
                  defaultValue=""
                  className="rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white"
                >
                  <option value="" disabled>
                    Select a range
                  </option>
                  {budgets.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </label>

              <Field
                label="Number of Travellers"
                name="travellers"
                type="number"
                placeholder="2"
                min={1}
              />

              <label className="flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70 sm:col-span-2">
                Message
                <textarea
                  name="message"
                  rows={3}
                  placeholder="Tell us anything else — occasion, must-see spots, pace of travel..."
                  className="resize-none rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 placeholder:text-primary-900/40 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white dark:placeholder:text-white/40"
                />
              </label>

              <button
                type="submit"
                className="mt-2 flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-bold text-white transition-colors hover:bg-primary-600 sm:col-span-2"
              >
                Send Enquiry
                <Send size={15} />
              </button>
            </form>
          )}
        </motion.div>
      </Container>
    </section>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required,
  min,
  className,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  min?: number;
  className?: string;
}) {
  return (
    <label
      className={`flex flex-col gap-1.5 text-xs font-semibold text-primary-900/70 dark:text-white/70 ${className ?? ""}`}
    >
      {label}
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        min={min}
        className="rounded-xl border border-primary-900/10 bg-white px-4 py-3 text-sm text-primary-900 placeholder:text-primary-900/40 focus:border-secondary focus:outline-none dark:border-white/15 dark:bg-primary-900 dark:text-white dark:placeholder:text-white/40"
      />
    </label>
  );
}
