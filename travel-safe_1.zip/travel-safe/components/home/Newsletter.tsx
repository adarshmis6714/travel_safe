"use client";

import { Container } from "@/components/ui/Container";
import { motion } from "framer-motion";
import { Mail, Send } from "lucide-react";
import { useState } from "react";

export function Newsletter() {
  const [done, setDone] = useState(false);

  return (
    <section className="bg-primary py-16">
      <Container>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="flex flex-col items-center justify-between gap-6 rounded-3xl bg-primary-800/60 p-8 text-center sm:flex-row sm:text-left"
        >
          <div className="flex items-center gap-4">
            <span className="hidden h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-white/10 text-secondary-300 sm:flex">
              <Mail size={20} />
            </span>
            <div>
              <h3 className="text-lg font-bold text-white">
                Get fare drops &amp; new itineraries first
              </h3>
              <p className="mt-1 text-sm text-white/60">
                One useful email a week. Unsubscribe anytime.
              </p>
            </div>
          </div>

          {done ? (
            <p className="text-sm font-semibold text-secondary-300">
              You&apos;re subscribed — welcome aboard!
            </p>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setDone(true);
              }}
              className="flex w-full max-w-sm items-center gap-2 rounded-full bg-white p-1.5"
            >
              <input
                type="email"
                required
                placeholder="you@example.com"
                className="w-full flex-1 bg-transparent px-3 py-2 text-sm text-primary-900 placeholder:text-primary-900/40 focus:outline-none"
              />
              <button
                type="submit"
                aria-label="Subscribe"
                className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-accent text-primary-900 transition-colors hover:bg-accent-300"
              >
                <Send size={15} />
              </button>
            </form>
          )}
        </motion.div>
      </Container>
    </section>
  );
}
