"use client";

import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { testimonials } from "@/lib/data";
import { motion } from "framer-motion";
import { Quote, Star } from "lucide-react";
import Image from "next/image";

export function Testimonials() {
  return (
    <section className="bg-primary-950 py-24 text-white">
      <Container>
        <SectionHeading
          eyebrow="Traveller Stories"
          title="15,000+ trips, told in their own words"
          align="center"
          className="mx-auto [&_h2]:text-white [&_span]:text-secondary-300"
        />
        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 4) * 0.1 }}
              className="flex flex-col rounded-3xl bg-white/5 p-6 backdrop-blur-sm"
            >
              <Quote size={22} className="text-secondary-400" />
              <p className="mt-4 flex-1 text-sm leading-relaxed text-white/80">
                &ldquo;{t.review}&rdquo;
              </p>
              <div className="mt-5 flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Star
                    key={s}
                    size={13}
                    className={s < t.rating ? "fill-accent text-accent" : "text-white/20"}
                  />
                ))}
              </div>
              <div className="mt-4 flex items-center gap-3 border-t border-white/10 pt-4">
                <div className="relative h-10 w-10 flex-shrink-0 overflow-hidden rounded-full">
                  <Image src={t.image} alt={t.name} fill sizes="40px" className="object-cover" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-xs text-white/50">{t.location}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
}
