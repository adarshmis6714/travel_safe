import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { PackageCard } from "@/components/ui/PackageCard";
import { Button } from "@/components/ui/Button";
import { packages } from "@/lib/data";

export function TrendingPackages() {
  return (
    <section className="bg-primary-50/50 py-24 dark:bg-primary-950/40" id="packages">
      <Container>
        <SectionHeading
          eyebrow="Trending Packages"
          title="This month's most booked itineraries"
          description="Transparent pricing, real inclusions, no surprise add-ons at checkout."
        />
        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {packages.slice(0, 6).map((pkg, i) => (
            <PackageCard key={pkg.slug} pkg={pkg} index={i} />
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <Button href="/destinations" variant="ghost" className="border border-primary-900/10 dark:border-white/15">
            View All Packages
          </Button>
        </div>
      </Container>
    </section>
  );
}
