"use client";

import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { galleryImages } from "@/lib/data";
import { motion } from "framer-motion";
import Image from "next/image";

const spanPattern = [
  "row-span-2",
  "row-span-1",
  "row-span-1",
  "row-span-2",
  "row-span-1",
  "row-span-2",
  "row-span-1",
  "row-span-1",
];

export function Gallery() {
  return (
    <section className="bg-white py-24 dark:bg-ink">
      <Container>
        <SectionHeading
          eyebrow="Moments"
          title="Trips our travellers keep talking about"
          align="center"
          className="mx-auto"
        />
        <div className="mt-10 grid auto-rows-[130px] grid-cols-2 gap-3 sm:grid-cols-4 sm:auto-rows-[160px]">
          {galleryImages.map((src, i) => (
            <motion.div
              key={src}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 8) * 0.06 }}
              className={`group relative overflow-hidden rounded-2xl ${spanPattern[i % spanPattern.length]}`}
            >
              <Image
                src={src}
                alt="Traveller moment captured by Travel Safe"
                fill
                sizes="(max-width: 768px) 45vw, 22vw"
                className="object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-primary-950/0 transition-colors duration-500 group-hover:bg-primary-950/20" />
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
}
