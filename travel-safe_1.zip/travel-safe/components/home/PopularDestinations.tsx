"use client";

import { DestinationCard } from "@/components/ui/DestinationCard";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { destinations } from "@/lib/data";
import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export function PopularDestinations() {
  const scrollerRef = useRef<HTMLDivElement>(null);

  function scroll(dir: 1 | -1) {
    scrollerRef.current?.scrollBy({ left: dir * 340, behavior: "smooth" });
  }

  return (
    <section className="bg-white py-24 dark:bg-ink" id="destinations">
      <Container>
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            eyebrow="Popular Destinations"
            title="Where travellers are heading this season"
            description="From island escapes to mountain valleys — ten destinations our travel experts vouch for personally."
          />
          <div className="hidden gap-2 sm:flex">
            <button
              aria-label="Scroll left"
              onClick={() => scroll(-1)}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-primary-900/10 text-primary-900 transition-colors hover:bg-primary hover:text-white dark:border-white/15 dark:text-white"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              aria-label="Scroll right"
              onClick={() => scroll(1)}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-primary-900/10 text-primary-900 transition-colors hover:bg-primary hover:text-white dark:border-white/15 dark:text-white"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </Container>

      <div
        ref={scrollerRef}
        className="mt-10 flex snap-x gap-6 overflow-x-auto px-5 pb-6 scrollbar-none sm:px-8"
        style={{ scrollbarWidth: "none" }}
      >
        <div className="flex-shrink-0 sm:w-[calc((100vw-1280px)/2)]" />
        {destinations.map((d, i) => (
          <div key={d.slug} className="w-[280px] flex-shrink-0 snap-start sm:w-[300px]">
            <DestinationCard destination={d} index={i} />
          </div>
        ))}
        <div className="flex-shrink-0 sm:w-[calc((100vw-1280px)/2)]" />
      </div>
    </section>
  );
}
