"use client";

import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { travelCategories } from "@/lib/data";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export function TravelCategories() {
  return (
    <section className="bg-primary-50/50 py-24 dark:bg-primary-950/40">
      <Container>
        <SectionHeading
          eyebrow="Travel Styles"
          title="Pick the way you want to travel"
          description="Every category comes with its own vetted hotel list and pacing template."
        />
        <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {travelCategories.map((cat, i) => (
            <motion.div
              key={cat.slug}
              initial={{ opacity: 0, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: (i % 4) * 0.08 }}
              className={i === 0 ? "col-span-2 row-span-2" : ""}
            >
              <Link
                href={`/destinations?category=${cat.slug}`}
                className="group relative flex h-full min-h-[180px] flex-col justify-end overflow-hidden rounded-3xl p-5"
              >
                <Image
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="(max-width: 768px) 45vw, 22vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-950/90 via-primary-950/20 to-transparent" />
                <div className="relative z-10 flex items-end justify-between gap-2">
                  <div>
                    <h3 className="text-base font-bold text-white sm:text-lg">
                      {cat.name}
                    </h3>
                    <p className="mt-1 hidden text-xs text-white/70 sm:block">
                      {cat.description}
                    </p>
                  </div>
                  <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur-sm transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
                    <ArrowUpRight size={15} />
                  </span>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
}
