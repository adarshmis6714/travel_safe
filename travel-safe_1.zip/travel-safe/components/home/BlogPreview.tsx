import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Button } from "@/components/ui/Button";
import { blogPosts } from "@/lib/data";
import { ArrowRight } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export function BlogPreview() {
  return (
    <section className="bg-primary-50/50 py-24 dark:bg-primary-950/40">
      <Container>
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <SectionHeading
            eyebrow="From the Journal"
            title="Travel tips, guides, and visa know-how"
          />
          <Button href="/blog" variant="ghost" className="border border-primary-900/10 dark:border-white/15">
            Visit the Blog
          </Button>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {blogPosts.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-card transition-shadow hover:shadow-card-hover dark:bg-primary-950"
            >
              <div className="relative h-40 w-full overflow-hidden">
                <Image
                  src={post.image}
                  alt={post.title}
                  fill
                  sizes="(max-width: 768px) 90vw, 25vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-primary-800">
                  {post.category}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="line-clamp-2 text-sm font-bold leading-snug text-primary-900 dark:text-white">
                  {post.title}
                </h3>
                <p className="mt-2 line-clamp-2 flex-1 text-xs leading-relaxed text-primary-900/55 dark:text-white/55">
                  {post.excerpt}
                </p>
                <div className="mt-4 flex items-center justify-between border-t border-primary-900/5 pt-3 text-[11px] text-primary-900/45 dark:border-white/10 dark:text-white/45">
                  <span>{post.readTime}</span>
                  <span className="flex items-center gap-1 font-semibold text-secondary-600 dark:text-secondary-300">
                    Read <ArrowRight size={12} />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </Container>
    </section>
  );
}
