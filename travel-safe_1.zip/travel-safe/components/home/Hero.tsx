"use client";

import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { motion } from "framer-motion";
import { MapPin, Search, ShieldCheck, Users, CalendarDays } from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";

const stats = [
  { icon: ShieldCheck, label: "Verified Stays", value: "500+" },
  { icon: Users, label: "Happy Travellers", value: "15,000+" },
];

export function Hero() {
  const router = useRouter();
  const [destination, setDestination] = useState("");

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    router.push(
      destination ? `/destinations?q=${encodeURIComponent(destination)}` : "/destinations"
    );
  }

  return (
    <section className="relative flex min-h-[100svh] w-full items-center overflow-hidden bg-primary-950">
      <Image
        src="https://images.unsplash.com/photo-1500835556837-99ac94a94552?q=80&w=2400&auto=format&fit=crop"
        alt="Cinematic view of a mountain lake at sunrise"
        fill
        priority
        sizes="100vw"
        className="object-cover opacity-90"
      />
      <div className="absolute inset-0 bg-hero-gradient" />
      <div className="absolute inset-0 bg-compass-radial" />

      <Container className="relative z-10 pt-28">
        <motion.span
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-white backdrop-blur-sm"
        >
          <ShieldCheck size={14} className="text-secondary-300" />
          India&apos;s Trust-First Travel Company
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-6 max-w-3xl text-balance text-4xl font-bold leading-[1.08] text-white sm:text-6xl"
        >
          Explore the World with{" "}
          <span className="relative inline-block text-secondary-300">
            Confidence
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-5 max-w-xl text-balance text-base leading-relaxed text-white/75 sm:text-lg"
        >
          Handpicked itineraries, verified hotels, and a 24x7 support team —
          every trip planned so the only thing you have to do is show up.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-8 flex flex-wrap gap-4"
        >
          <Button href="/destinations" size="lg" variant="secondary">
            Explore Packages
          </Button>
          <Button href="/contact" size="lg" variant="outline">
            Plan My Trip
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mt-10 flex gap-8"
        >
          {stats.map(({ icon: Icon, label, value }) => (
            <div key={label} className="flex items-center gap-2.5 text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
                <Icon size={16} className="text-secondary-300" />
              </span>
              <div>
                <p className="text-sm font-bold leading-none">{value}</p>
                <p className="mt-1 text-[11px] text-white/60">{label}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </Container>

      <motion.form
        onSubmit={handleSearch}
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.45 }}
        className="glass absolute inset-x-0 bottom-0 z-10 mx-auto w-[92%] max-w-4xl translate-y-1/2 rounded-2xl p-2 shadow-glass sm:p-2.5"
      >
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <label className="flex flex-1 items-center gap-3 rounded-xl px-4 py-3">
            <MapPin size={18} className="flex-shrink-0 text-secondary-600" />
            <input
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              type="text"
              placeholder="Where do you want to go?"
              className="w-full bg-transparent text-sm text-primary-900 placeholder:text-primary-900/40 focus:outline-none dark:text-white dark:placeholder:text-white/40"
            />
          </label>
          <div className="hidden h-8 w-px bg-primary-900/10 sm:block dark:bg-white/10" />
          <label className="flex flex-1 items-center gap-3 rounded-xl px-4 py-3">
            <CalendarDays size={18} className="flex-shrink-0 text-secondary-600" />
            <input
              type="text"
              placeholder="Travel month"
              className="w-full bg-transparent text-sm text-primary-900 placeholder:text-primary-900/40 focus:outline-none dark:text-white dark:placeholder:text-white/40"
            />
          </label>
          <div className="hidden h-8 w-px bg-primary-900/10 sm:block dark:bg-white/10" />
          <label className="flex flex-1 items-center gap-3 rounded-xl px-4 py-3">
            <Users size={18} className="flex-shrink-0 text-secondary-600" />
            <input
              type="text"
              placeholder="Travellers"
              className="w-full bg-transparent text-sm text-primary-900 placeholder:text-primary-900/40 focus:outline-none dark:text-white dark:placeholder:text-white/40"
            />
          </label>
          <button
            type="submit"
            className="flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-sm font-bold text-white transition-colors hover:bg-primary-600"
          >
            <Search size={16} />
            Search
          </button>
        </div>
      </motion.form>
    </section>
  );
}
