"use client";

import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { motion } from "framer-motion";
import {
  BadgeIndianRupee,
  Headset,
  Hotel,
  Route,
  ShieldCheck,
  Users2,
} from "lucide-react";

const features = [
  {
    icon: BadgeIndianRupee,
    title: "Best Price Guarantee",
    description: "Find it cheaper elsewhere within 24 hours and we match it, no questions asked.",
  },
  {
    icon: Users2,
    title: "Trusted Travel Experts",
    description: "Every itinerary is built and reviewed by destination specialists, not algorithms alone.",
  },
  {
    icon: Headset,
    title: "24x7 Support",
    description: "A dedicated coordinator stays reachable before, during, and after your trip.",
  },
  {
    icon: ShieldCheck,
    title: "Secure Booking",
    description: "Encrypted payments and a Travel Safe Score on every listing you browse.",
  },
  {
    icon: Hotel,
    title: "Handpicked Hotels",
    description: "Every property is site-inspected or vetted against verified guest reviews.",
  },
  {
    icon: Route,
    title: "Custom Itineraries",
    description: "Swap a day, add a city, or go fully bespoke — we replan without extra fees.",
  },
];

export function WhyChooseUs() {
  return (
    <section className="bg-white py-24 dark:bg-ink">
      <Container>
        <SectionHeading
          eyebrow="Why Travel Safe"
          title="Confidence built into every step of the trip"
          align="center"
          className="mx-auto"
        />
        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
              whileHover={{ y: -6 }}
              className="group rounded-3xl border border-primary-900/5 bg-white p-7 shadow-card transition-shadow hover:shadow-card-hover dark:border-white/10 dark:bg-primary-950"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary transition-colors group-hover:bg-primary group-hover:text-white dark:bg-white/10 dark:text-secondary-300">
                <f.icon size={22} />
              </span>
              <h3 className="mt-5 text-lg font-bold text-primary-900 dark:text-white">
                {f.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-primary-900/60 dark:text-white/60">
                {f.description}
              </p>
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
}
